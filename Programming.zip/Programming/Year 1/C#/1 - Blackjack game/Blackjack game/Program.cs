﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace Blackjack_game
{
    class Program
    {
        //variables can be called in any piece of code
        static string[] sPlayercards = new string[11];
        static string sHitorstick = "";
        static string sName;
        static int iPlayercardtotal = 0; 
        static int iCount = 1; 
        static int iDealercardtotal = 0;
        static Random CardChooser = new Random();
        static int iGamesplayed = 0;
        
        //game menu and start section
        static void Main(string[] args)
        {
            int iMenuChoice;
            const String sFilename = "players.txt";

            //changes command prompt title and font colour
            Console.Title = "Blackjack Game";
            Console.ForegroundColor = ConsoleColor.Green;

            // Puts menu options in window
            Console.WriteLine("Blackjack Game");
            Console.WriteLine();
            Console.WriteLine("1: Instructions");
            Console.WriteLine("2: Play Game");
            Console.WriteLine("3: Previous Players Names");
            Console.WriteLine("4: Exit");

            //asks which menu you want to go to
            Console.WriteLine();
            Console.Write("Enter number for corresponding menu option: ");
            iMenuChoice = Convert.ToInt32(Console.ReadLine());

            //validates menu choice
            while (iMenuChoice < 1 || iMenuChoice > 4)
            {
                Console.Write("Please enter the corresponding menu number: ");
                iMenuChoice = Convert.ToInt32(Console.ReadLine());
            }

            // Keeps program running until the user selects exit
            while (iMenuChoice != 4)
            {
                Console.Clear();

                // selects which menu to load
                switch (iMenuChoice)
                {
                    case 1: //instructions menu option
                        //Writes out rules of the game
                        Console.WriteLine("This is a simple game of blackjack.");
                        Console.WriteLine();
                        Console.WriteLine("The aim of the game is to get your cards to total 21 or get as close as");
                        Console.WriteLine("possible without going over");
                        Console.WriteLine();
                        Console.WriteLine("You will also be competing against the computer to try and get 21");
                        Console.WriteLine();
                        Console.WriteLine("If the computer is closer or you go over you will lose the game");
                        Console.WriteLine();
                        Console.WriteLine("If you want to stay at your current number you can type stick but can also type");
                        Console.WriteLine("hit if you wish to add another card to your total");
                        
                        break;

                    case 2: //start game menu option

                        Console.WriteLine("Welcome to the game of blackjack");
                        Console.WriteLine();
                        Console.WriteLine("Please enter your name:");
                        sName = Console.ReadLine(); //stores users name

                        //writes users name and games played to text document
                        using (StreamWriter sw = new StreamWriter(sFilename, true))
                        {
                            sw.WriteLine(sName + ", " + iGamesplayed);
                            sw.Close();
                        }
                        
                        Console.WriteLine();
                        Console.WriteLine("Press any key to start");
                        Console.ReadKey();
                        Console.Clear();

                        Startgame(); //calls code which initiates game

                        break;

                    case 3: //previous players names menu option
                        
                        Console.WriteLine();
                        Console.WriteLine("Current Scoreboard");
                        Console.WriteLine();

                        // reads name and games played from text document and outputs to screen
                        using (StreamReader sr = new StreamReader(sFilename))
                        {
                            while (sr.Peek() != -1)
                            {
                                Console.WriteLine(sr.ReadLine() + " Games played in one session");
                            }
                            sr.Close();
                        }
                        break;

            }
                //lets you return to main menu
                Console.WriteLine();
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
                Console.Clear();

                Console.WriteLine("Blackjack Game");
                Console.WriteLine();
                Console.WriteLine("1: Instructions");
                Console.WriteLine("2: Play Game");
                Console.WriteLine("3: Biggest Winners");
                Console.WriteLine("4: Exit");

                Console.WriteLine();
                Console.Write("Enter number for corresponding menu option: ");
                iMenuChoice = Convert.ToInt32(Console.ReadLine());

                //makes sure menu choice is valid
                while (iMenuChoice < 1 || iMenuChoice > 4)
                {
                    Console.WriteLine();
                    Console.Write("Please enter a value between (1-4): ");
                    iMenuChoice = Convert.ToInt32(Console.ReadLine());
                }



        }
    }
        //Main game code
        static void Startgame()
        {
            iDealercardtotal = CardChooser.Next(15, 22); //generates dealer cards value
            sPlayercards[0] = Dealcard();
            sPlayercards[1] = Dealcard();

            //tells you what your dealt
            Console.WriteLine();
            Console.WriteLine("You have been dealt a " + sPlayercards[0] + " & " + sPlayercards[1]);
            Console.WriteLine();
            Console.WriteLine("Your current card total = " + iPlayercardtotal);

            Console.WriteLine();
            Console.WriteLine("Would you like to 'hit' or 'stick'?");
            Console.WriteLine();
            sHitorstick = Convert.ToString(Console.ReadLine());//stores option as string

            //validates whether hit or stick typed
            while (sHitorstick != "hit" || sHitorstick != "stick")
            {

                if (sHitorstick == "hit" || sHitorstick == "stick")
                {
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("I think you made an error");
                    Console.WriteLine("Please enter either 'hit' or 'stick'");
                    sHitorstick = Convert.ToString(Console.ReadLine());
                }
                 
                //when validation passes calls the game code
                while (sHitorstick.Equals("hit") || sHitorstick.Equals("stick"))
                {
                    Game();
                }
            }
        }

        //code behind dealing cards
        static string Dealcard()
        {
            string sCard = "";
            int iCards = CardChooser.Next(1, 14); //randomly selects which card users going to get
            switch (iCards)
            {
                case 1:
                    sCard = "Two"; iPlayercardtotal += 2; //name of card and how much its worth
                    break;
                case 2:
                    sCard = "Three"; iPlayercardtotal += 3;
                    break;
                case 3:
                    sCard = "Four"; iPlayercardtotal += 4;
                    break;
                case 4:
                    sCard = "Five"; iPlayercardtotal += 5;
                    break;
                case 5:
                    sCard = "Six"; iPlayercardtotal += 6;
                    break;
                case 6:
                    sCard = "Seven"; iPlayercardtotal += 7;
                    break;
                case 7:
                    sCard = "Eight"; iPlayercardtotal += 8;
                    break;
                case 8:
                    sCard = "Nine"; iPlayercardtotal += 9;
                    break;
                case 9:
                    sCard = "Ten"; iPlayercardtotal += 10;
                    break;
                case 10:
                    sCard = "Jack"; iPlayercardtotal += 10;
                    break;
                case 11:
                    sCard = "Queen"; iPlayercardtotal += 10;
                    break;
                case 12:
                    sCard = "King"; iPlayercardtotal += 10;
                    break;
                case 13:
                    sCard = "Ace"; iPlayercardtotal += 11;
                    break;
                default: sCard = "2"; iPlayercardtotal += 2;
                    break;
            }
            return sCard; //outputs card name to screen

        }


        //runs hit and works out if someone has won
        static void Game()
        {
            if (sHitorstick == "hit")
            {
                Playercardhit(); //runs code so extra card generated for player
            }
            else if (sHitorstick.Equals("stick"))
            {
                if (iPlayercardtotal > iDealercardtotal && iPlayercardtotal <= 21)//checks if user won
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("You Won");
                    Console.WriteLine("The dealer only had " + iDealercardtotal); //tells you youve won and ask if you want to play again
                    Console.WriteLine();
                    Console.WriteLine("Would you like to play again yes/no?");
                    PlayAgain(); //Call the method 'PlayAgain()'.
                }
                else if (iPlayercardtotal < iDealercardtotal && iDealercardtotal <= 21) // if our total is less than the dealer's..
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("You lost the dealer's had " + iDealercardtotal);
                    Console.WriteLine();
                    Console.WriteLine("Would you like to play again? yes/no?");
                    PlayAgain(); //Calls the code that asks if they want to play again
                }
                else if (iPlayercardtotal >= 22 && iDealercardtotal >= 22) //checks if both players lost
                {
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("Both players were bust");
                    Console.WriteLine("You both lose");
                    Console.WriteLine("Would you like to play again yes/no?");
                    PlayAgain(); //Calls the code that asks if they want to play again
                }
            }
        }


        static void Playercardhit()
        {
            iCount++; //adds 1 to count so can deal another card

            sPlayercards[iCount] = Dealcard(); //gives player another card 
            Console.WriteLine();
            Console.WriteLine("You new card is a " + sPlayercards[iCount]);// tell the user what they were dealed
            Console.WriteLine("Your total is now " + iPlayercardtotal); 

            if (iPlayercardtotal.Equals(21)) // if their total is 21 (Blackjack)
            {
                Console.Clear();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("You got Blackjack!");//Tell the user they got blackjack
                Console.WriteLine("The dealer's total was only " + iDealercardtotal); 
                Console.WriteLine();
                Console.WriteLine("Would you like to play again yes/no?");
                PlayAgain(); //Calls the code that asks if they want to play again
            }
            else if (iPlayercardtotal > 21) // if their total is greater than 21 (bust)
            {
                Console.Clear();
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("You had " + iPlayercardtotal);
                Console.WriteLine("You are bust");
                Console.WriteLine("The dealer's total was " + iDealercardtotal); // Tell the user they busted, tell them the dealer's total, and ask them to play again
                Console.WriteLine();
                Console.WriteLine("Would you like to play again yes/no?");
                PlayAgain(); //Calls the code that asks if they want to play again
            }
            else // otherwise.. (less than 21)
            {
                Console.WriteLine();
                Console.WriteLine("Would you like to 'hit' or 'stick'?");
                sHitorstick = Convert.ToString(Console.ReadLine());
            }

            // validates whether correct option selected
            while (sHitorstick != "hit" || sHitorstick != "stick")
            {
                if (sHitorstick.Equals("hit") || sHitorstick.Equals("stick")) 
                {
                    Game();
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("I think you made an error");
                    Console.WriteLine("Please enter 'hit' or 'stick'");
                    sHitorstick = Convert.ToString(Console.ReadLine());
                }
            }
        }

        //determines whether to reload or exit game
        static void PlayAgain()
        {
            string sPlayAgain = ""; //stores users selected option

            sPlayAgain = Console.ReadLine();


            while (sPlayAgain != "yes" || sHitorstick != "no")
            {
                // validates whether correct option selected
                if (sPlayAgain.Equals("yes") || sPlayAgain.Equals("no")) 
                {
                    if (sPlayAgain.Equals("yes")) // if they want to play again..
                    {
                        Console.WriteLine();

                        Console.Clear(); // Clear the Console
                        iDealercardtotal = 0; // reset the dealer total
                        iCount = 1; // reset the count
                        iGamesplayed++; //adds 1 to games played
                        iPlayercardtotal = 0; // reset our total
                        Startgame(); //runs code to restart game
                    }
                    else if (sPlayAgain.Equals("no"))
                    {
                        iGamesplayed++;
                        Environment.Exit(0); //closes command prompt
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("I think you made an error");
                    Console.WriteLine("Please enter yes/no");
                    sPlayAgain = Convert.ToString(Console.ReadLine());
                }
            }


           }
        }
     }






