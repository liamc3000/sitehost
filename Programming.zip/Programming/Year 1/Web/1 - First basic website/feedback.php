<?php


//change the email address in the line below, to YOUR email address
$youremailaddress = "bg10ch@student.sunderland.ac.uk";




//---leave everything below this line the same.


if (isset($_REQUEST['email']))
//if "email" is filled out, send email
  {
  //send email
  $email = $_REQUEST['email'] ;
  $name = $_REQUEST['name'] ;
  $message = $_REQUEST['message'] ;
  mail("$youremailaddress", "feedback from your website form",
  $message, "From:" . $email);
  echo "Thank you for using our mail form";
  }
else
//if "email" is not filled out, display the form
  {
  echo "The form was not filled out correctly, press the back button and try again";
  }
?>