﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_3
{
    public partial class AddSale : System.Web.UI.Page
    {
        SaleList saleList = new SaleList();

        protected void chkCharity_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCharity.Checked == true)
            {
                txtCharityName.Enabled = true;
            }

            else
            {
                txtCharityName.Enabled = false;
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            GetData();
            Response.Redirect("CarBootSales.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("CarBootSales.aspx");
        }

        public void GetData()
        {
            if (Session["CarBootList"] != "")
            {
                SaleList convert = Session["CarBootList"] as SaleList;
                
                saleList = convert;
            }
         
            
            string date;
            date = Convert.ToString(dropDay.Text) + "/" + Convert.ToString(dropMonth.Text) + "/" + Convert.ToString(dropYear.Text);
            DateTime dateTime = Convert.ToDateTime(date);

            Sale newSale = new Sale(txtId.Text, dateTime, txtLocation.Text, Convert.ToDouble(txtPitchCost.Text), Convert.ToInt32(txtNumPitches.Text), chkCharity.Checked, txtCharityName.Text, chkCatering.Checked);
            saleList.addSale(newSale);

            Session["CarBootSale"] = newSale;
            Session["CarBootList"] = saleList;
        }

       

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

    }
}