﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_3
{
    public partial class CarBootSales : System.Web.UI.Page
    {

        #region SET UP 

        SaleList saleList;

        #endregion SET UP

        #region BUTTONS


        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveData();
            }
            catch (Exception ex)
            {
                messageLabel.Text = "Cannot save data. Error: " + ex.Message;
            }
        }

        protected void btnLoad_Click(object sender, EventArgs e)
        {
            if (Session["CarBootList"] != "")
            {
                try
                {
                    UpdateListbox();
                }
                catch (Exception ex)
                {
                    messageLabel.Text = "Error encountered: " + ex.Message;
                }
            }
            else
            {
                LoadData();
            }                  
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
            RemoveSale();
        }

        protected void btnAddNewSale_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddSale.aspx");
        }

        protected void btnAllReport_Click(object sender, EventArgs e)
        {
            RunReportAll();
            RunReportCharity();
            RunReportNonCharity();
        }

        #endregion BUTTONS

        #region METHODS

        public void SaveData()
        {
            SaleList saleList = Session["CarBootList"] as SaleList;
            SerializeFileHandler sr = new SerializeFileHandler();
            sr.WriteSaleListToFile(saleList, Server.MapPath("bin\\data.dat"));
        }

        public void LoadData()
        {
            SerializeFileHandler sr = new SerializeFileHandler();
            saleList = sr.ReadSaleListFromFile(Server.MapPath("bin\\data.dat"));
            LoadListbox();
            
            Session["CarBootList"] = saleList;
            
        }

        public void RunReportAll()
        {
            SaleList saleList = Session["CarBootList"] as SaleList;
            TextReportGenerator trg = new TextReportGenerator(saleList);
            trg.GenerateReportAll(Server.MapPath("report_all.txt"));
        }

        public void RunReportCharity()
        {
            SaleList saleList = Session["CarBootList"] as SaleList;
            TextReportGenerator trg = new TextReportGenerator(saleList);
            trg.GenerateReportCharity(Server.MapPath("report_charity.txt"));
        }

        public void RunReportNonCharity()
        {
            SaleList saleList = Session["CarBootList"] as SaleList;
            TextReportGenerator trg = new TextReportGenerator(saleList);
            trg.GenerateReportNonCharity(Server.MapPath("report_noncharity.txt"));
        }

        private void UpdateListbox()
        {
            SaleList saleList = Session["CarBootList"] as SaleList;
            lstCarBoots.Items.Clear();
            
            for (int i = 0; i < saleList.Count(); i++)
            {
                lstCarBoots.Items.Add(saleList.getSale(i).ToString());
            }
        }

        private void LoadListbox()
        {
            lstCarBoots.Items.Clear();

            for (int i = 0; i < saleList.Count(); i++)
            {
                lstCarBoots.Items.Add(saleList.getSale(i).ToString());
            }
        }

        public void RemoveSale()
        {

            SaleList saleList = Session["CarBootList"] as SaleList;

            if (lstCarBoots.Items.Count > 0 && lstCarBoots.SelectedIndex >= 0)
            {
                int decision = lstCarBoots.SelectedIndex;
                lstCarBoots.Items.RemoveAt(lstCarBoots.SelectedIndex);
                saleList.removeSale(decision);

                if (lstCarBoots.Items.Count > 0)
                {
                    lstCarBoots.SelectedIndex = 0;
                }

            }
        }

        #endregion METHODS

    }
}