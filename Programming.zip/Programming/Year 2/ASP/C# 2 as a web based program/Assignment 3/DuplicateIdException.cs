﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    class DuplicateIdException : Exception
    {
        private static String msg = "Duplicate id numbers not allowed";

        public DuplicateIdException()
            : base(msg)
        {
        }
    }
}