﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    interface IFileHandler
    {
        void WriteSaleListToFile(SaleList saleList, String filePath);
        SaleList ReadSaleListFromFile(String filePath);
    }
}