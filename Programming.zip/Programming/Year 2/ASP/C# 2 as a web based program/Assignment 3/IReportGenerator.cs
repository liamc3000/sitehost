﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    interface IReportGenerator
    {
        void GenerateReportAll(String filePath);
        void GenerateReportCharity(String filePath);
        void GenerateReportNonCharity(String filePath);
    }
}