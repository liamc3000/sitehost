﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    interface ISaleManagerUI
    {
        void RunReportAll();
        void RunReportCharity();
        void RunReportNonCharity();
        void SaveData();
        void LoadData();
        void RemoveSale();
    }
}