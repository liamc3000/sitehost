﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    [Serializable]
    public class Sale : IComparable<Sale>
    {
        private String saleId;

        public String SaleId
        {
            get { return saleId; }
            set { saleId = value; }
        }

        private DateTime saleDate;
        private String location;
        private double pitchCost;
        private int numPitches;
        private bool charity;

        public bool Charity
        {
            get { return charity; }
            set { charity = value; }
        }

        private String charityName;
        private bool catering;

        public Sale(String saleId,
                        DateTime saleDate,
                        String location,
                        double pitchCost,
                        int numPitches,
                        bool charity,
                        String charityName,
                        bool catering)
        {
            this.saleId = saleId;
            this.saleDate = saleDate;
            this.location = location;
            this.pitchCost = pitchCost;
            this.numPitches = numPitches;
            this.charity = charity;
            this.charityName = charityName;
            this.catering = catering;
        }

        public override string ToString()
        {
            String str;

            String charityString;
            String cateringString;
            String charityNameString;

            if (charity)
            {
                charityString = "Yes";
                charityNameString = charityName;
            }
            else
            {
                charityString = "No";
                charityNameString = "N/A";
            }

            if (catering)
            {
                cateringString = "Yes";
            }
            else
            {
                cateringString = "No";
            }

            str = String.Format("Id: {0} Date: {1} Location: {2} Pitch Cost: {3} #Pitches: {4} Charity: {5} Charity Name: {6} Catering: {7}",
                                    saleId,
                                    saleDate.Date.ToShortDateString(),
                                    location,
                                    pitchCost,
                                    numPitches,
                                    charityString,
                                    charityNameString,
                                    cateringString);
            return str;
        }

        public int CompareTo(Sale sale)
        {
            return this.SaleId.CompareTo(sale.SaleId);
        }
    }
}