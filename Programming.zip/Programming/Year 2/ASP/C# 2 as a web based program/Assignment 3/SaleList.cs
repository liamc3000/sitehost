﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    [Serializable]
    class SaleList
    {
        private List<Sale> saleList;

        public SaleList()
        {
            saleList = new List<Sale>();
        }

        public void addSale(Sale sale)
        {
            //Make sure a sale with this id does not already exist

            foreach (Sale s in saleList)
            {
                if (s.SaleId == sale.SaleId)
                {
                    throw new DuplicateIdException();
                }
            }

            saleList.Add(sale);
        }

        public void removeSale(int index)
        {
            saleList.RemoveAt(index);
        }

        public void removeSale(Sale sale)
        {
            saleList.Remove(sale);
        }

        public Sale getSale(int index)
        {
            return saleList[index];
        }

        public int Count()
        {
            return saleList.Count;
        }

        public void Sort()
        {
            saleList.Sort();
        }
    }
}