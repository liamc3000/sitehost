﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    class SaleListSorterFilterer
    {
        public static SaleList SortById(SaleList saleList)
        {
            SaleList sortedSaleList = new SaleList();

            for (int i = 0; i < saleList.Count(); i++)
            {
                sortedSaleList.addSale(saleList.getSale(i));
            }

            sortedSaleList.Sort();

            return sortedSaleList;
        }

        public static SaleList FilterCharity(SaleList saleList)
        {
            SaleList filteredSaleList = new SaleList();

            for (int i = 0; i < saleList.Count(); i++)
            {
                if (saleList.getSale(i).Charity)
                {
                    filteredSaleList.addSale(saleList.getSale(i));
                }
            }

            return filteredSaleList;
        }

        public static SaleList FilterNonCharity(SaleList saleList)
        {
            SaleList filteredSaleList = new SaleList();

            for (int i = 0; i < saleList.Count(); i++)
            {
                if (!saleList.getSale(i).Charity)
                {
                    filteredSaleList.addSale(saleList.getSale(i));
                }
            }

            return filteredSaleList;
        }
    }
}