﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Assignment_3
{
    class SerializeFileHandler : IFileHandler
    {
        public void WriteSaleListToFile(SaleList saleList, String filePath)
        {
            FileStream outFile;
            BinaryFormatter bFormatter = new BinaryFormatter();

            // open file for output
            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);

            // output object to file via serialization
            bFormatter.Serialize(outFile, saleList);

            // close file
            outFile.Close();
        }

        public SaleList ReadSaleListFromFile(String filePath)
        {
            FileStream inFile;
            SaleList saleList = null;
            BinaryFormatter bFormatter = new BinaryFormatter();

            // open file for input
            inFile = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            // keep going while there are still records to read
            while (inFile.Position < inFile.Length)
            {
                // obtain object from file via serialization
                saleList = (SaleList)bFormatter.Deserialize(inFile);
            }

            // close file
            inFile.Close();

            return saleList;
        }
    }
}