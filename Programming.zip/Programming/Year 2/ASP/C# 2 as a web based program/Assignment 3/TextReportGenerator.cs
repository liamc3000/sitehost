﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;

namespace Assignment_3
{
    class TextReportGenerator : IReportGenerator
    {
        public readonly SaleList saleList;

        public TextReportGenerator(SaleList saleList)
        {
            this.saleList = saleList;
        }

        public void GenerateReportAll(String filePath)
        {
            CreateReport(filePath, SaleListSorterFilterer.SortById(saleList));
        }

        public void GenerateReportCharity(String filePath)
        {
            CreateReport(filePath, SaleListSorterFilterer.FilterCharity(SaleListSorterFilterer.SortById(saleList)));
        }

        public void GenerateReportNonCharity(String filePath)
        {
            CreateReport(filePath, SaleListSorterFilterer.FilterNonCharity(SaleListSorterFilterer.SortById(saleList)));
        }

        private void CreateReport(String filePath, SaleList saleList)
        {
            FileStream outFile;
            StreamWriter writer;

            outFile = new FileStream(filePath, FileMode.Create,
                                     FileAccess.Write);
            writer = new StreamWriter(outFile);

            for (int i = 0; i < saleList.Count(); i++)
            {
                Sale s = saleList.getSale(i);

                // output sale details
                writer.WriteLine(s.ToString());
            }

            // close writer
            writer.Close();

            // close file
            outFile.Close();
        }
    }
}