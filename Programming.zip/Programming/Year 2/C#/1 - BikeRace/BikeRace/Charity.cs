﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BikeRace
{
    class Charity : Cyclist
    {
        public String charityName;
        public Double amountRaised;
        public String isNovelty;

        //stores properties for charity name
        public String CharitytName
        {
            get
            {
                return charityName;
            }
            set
            {
                charityName = value;
            }
        }

        //stores properties for sponsorship
        public Double SponsorShip
        {
            get
            {
                return amountRaised;
            }
            set
            {
                amountRaised = value;
            }
        }

        //sets default values to nothing
        public Charity()
        {
            CyclistNumber = 0;
            charityName = "";
            amountRaised = 0;
        }

        //populates the parameters
        public Charity(int cyclistnumber, String charityName, Double sponsorShip)
        {
            this.CyclistNumber = cyclistnumber;
            this.charityName = charityName;
            this.amountRaised = sponsorShip;
        }

        //writes out data values
        public override string ToString()
        {
            return "Cyclist Number: " + CyclistNumber + ",   Charity Name: " + charityName + ",   Sponsorship: £" + amountRaised;
        }
    }
}
