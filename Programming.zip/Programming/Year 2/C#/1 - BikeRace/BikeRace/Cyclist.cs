﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BikeRace
{
    class Cyclist
    {
        private int maxCyclists = 10;

        private Cyclist[] cyclistList;
        private int cyclistCount;

        private int cyclistNumber;
        private String didFinish;

        //holds properties for cyclist numbers
        public int CyclistNumber
        {
            get
            {
                return cyclistNumber;
            }
            set
            {
                cyclistNumber = value;
            }
        }

        //stores properties for whether they finished race
        public String DidFinish
        {
            get
            {
                return didFinish;
            }
            set
            {
                didFinish = value;
            }
        }

        public Cyclist()
        {
            //sets default cyclist number to zero
            cyclistNumber = 0;
        }

        public Cyclist(int cyclistNumber)
        {
            //sets cyclist number to value
            this.cyclistNumber = cyclistNumber;
        }  

        public override string ToString()
        {
            //returns correct information
            return "Cyclist Number: " + cyclistNumber;
        }

        public int CyclistCount
        {
            get
            {
                return cyclistCount;
            }
            set
            {
                cyclistCount = value;
            }
        }

        public Cyclist(String location)
        {
            //limits maximum amount of cyclists
            cyclistList = new Cyclist[maxCyclists];
            cyclistCount = 0;
        }

        public bool AddCyclist(Cyclist cyclist)
        {
            if (cyclistCount < maxCyclists)
            {
                //adds cyclists to array
                cyclistList[cyclistCount] = cyclist;
                cyclistCount++;
                return true;
            }
            else
            {
                return false;
            }
        }

        public Cyclist GetCyclist(int index)
        {
            if (index < cyclistCount)
            {
                return cyclistList[index];
            }
            else
            {
                return null;
            }
        }

        public int racesFinished { get; set; }

        public string finishTime { get; set; }
    }
}
