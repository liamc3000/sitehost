﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BikeRace
{
    class FinishLine : Cyclist
    {
        public int totalFinishes;

        //stores properties for finish time
        public String FinishTime
        {
            get
            {
                return finishTime;
            }
            set
            {
                finishTime = value;
            }
        }

        //stores properties for total finishes
        public int TotalFinishes
        {
            get
            {
                return totalFinishes;
            }
            set
            {
                totalFinishes = value;
            }
        }
    }
}
