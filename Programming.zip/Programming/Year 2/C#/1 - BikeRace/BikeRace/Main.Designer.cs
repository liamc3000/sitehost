﻿namespace BikeRace
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstCompetingCyclists = new System.Windows.Forms.ListBox();
            this.lstCyclistsTime = new System.Windows.Forms.ListBox();
            this.lblCompeting = new System.Windows.Forms.Label();
            this.lblCyclist = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblGuide = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtFinishingTime = new System.Windows.Forms.TextBox();
            this.lblFinish = new System.Windows.Forms.Label();
            this.lblCounter = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstCompetingCyclists
            // 
            this.lstCompetingCyclists.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCompetingCyclists.FormattingEnabled = true;
            this.lstCompetingCyclists.ItemHeight = 15;
            this.lstCompetingCyclists.Location = new System.Drawing.Point(12, 47);
            this.lstCompetingCyclists.Name = "lstCompetingCyclists";
            this.lstCompetingCyclists.Size = new System.Drawing.Size(864, 169);
            this.lstCompetingCyclists.TabIndex = 0;
            this.lstCompetingCyclists.SelectedIndexChanged += new System.EventHandler(this.lstCompetingCyclists_SelectedIndexChanged);
            // 
            // lstCyclistsTime
            // 
            this.lstCyclistsTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCyclistsTime.FormattingEnabled = true;
            this.lstCyclistsTime.ItemHeight = 15;
            this.lstCyclistsTime.Location = new System.Drawing.Point(12, 252);
            this.lstCyclistsTime.Name = "lstCyclistsTime";
            this.lstCyclistsTime.Size = new System.Drawing.Size(233, 169);
            this.lstCyclistsTime.TabIndex = 9;
            // 
            // lblCompeting
            // 
            this.lblCompeting.AutoSize = true;
            this.lblCompeting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompeting.Location = new System.Drawing.Point(9, 20);
            this.lblCompeting.Name = "lblCompeting";
            this.lblCompeting.Size = new System.Drawing.Size(205, 15);
            this.lblCompeting.TabIndex = 2;
            this.lblCompeting.Text = "Competing Cyclists Information";
            // 
            // lblCyclist
            // 
            this.lblCyclist.AutoSize = true;
            this.lblCyclist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCyclist.Location = new System.Drawing.Point(12, 233);
            this.lblCyclist.Name = "lblCyclist";
            this.lblCyclist.Size = new System.Drawing.Size(91, 15);
            this.lblCyclist.TabIndex = 3;
            this.lblCyclist.Text = "Cyclists Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(389, 391);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "No. of Finished Cyclists :";
            // 
            // lblGuide
            // 
            this.lblGuide.AutoSize = true;
            this.lblGuide.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuide.Location = new System.Drawing.Point(562, 254);
            this.lblGuide.Name = "lblGuide";
            this.lblGuide.Size = new System.Drawing.Size(69, 15);
            this.lblGuide.TabIndex = 5;
            this.lblGuide.Text = "HH:MM:SS";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(561, 299);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(70, 31);
            this.btnSubmit.TabIndex = 4;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtFinishingTime
            // 
            this.txtFinishingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFinishingTime.Location = new System.Drawing.Point(559, 272);
            this.txtFinishingTime.Name = "txtFinishingTime";
            this.txtFinishingTime.Size = new System.Drawing.Size(72, 21);
            this.txtFinishingTime.TabIndex = 1;
            // 
            // lblFinish
            // 
            this.lblFinish.AutoSize = true;
            this.lblFinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinish.Location = new System.Drawing.Point(391, 275);
            this.lblFinish.Name = "lblFinish";
            this.lblFinish.Size = new System.Drawing.Size(162, 15);
            this.lblFinish.TabIndex = 0;
            this.lblFinish.Text = "Cyclists Finishing Time :";
            // 
            // lblCounter
            // 
            this.lblCounter.AutoSize = true;
            this.lblCounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCounter.Location = new System.Drawing.Point(562, 391);
            this.lblCounter.Name = "lblCounter";
            this.lblCounter.Size = new System.Drawing.Size(0, 15);
            this.lblCounter.TabIndex = 11;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 433);
            this.Controls.Add(this.lblGuide);
            this.Controls.Add(this.lblCounter);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtFinishingTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblFinish);
            this.Controls.Add(this.lblCyclist);
            this.Controls.Add(this.lblCompeting);
            this.Controls.Add(this.lstCyclistsTime);
            this.Controls.Add(this.lstCompetingCyclists);
            this.Name = "frmMain";
            this.Text = "Race Information";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstCompetingCyclists;
        private System.Windows.Forms.ListBox lstCyclistsTime;
        private System.Windows.Forms.Label lblCompeting;
        private System.Windows.Forms.Label lblCyclist;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFinishingTime;
        private System.Windows.Forms.Label lblFinish;
        private System.Windows.Forms.Label lblGuide;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblCounter;

        public System.EventHandler txtFinishingTime_TextChanged { get; set; }
    }
}

