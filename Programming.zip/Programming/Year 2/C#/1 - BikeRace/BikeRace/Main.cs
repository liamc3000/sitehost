﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BikeRace
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private Cyclist cyclist;

        public int finishcount;

        private void frmMain_Load(object sender, EventArgs e)
        {
            //creates array and adds cyclists to it
            cyclist = new Cyclist("Bike Race");

            Cyclist cyc1 = new Novelty(1, "Yes", "Unicef", 45, "Unicycle", 1);
            Cyclist cyc2 = new Professional(2, "Yes", 21, 1);
            Cyclist cyc3 = new Novelty(3, "Yes", "Marie Curie Cancer Care", 200, "Flinstones car", 4);
            Cyclist cyc4 = new Novelty(4, "Yes", "Invest in Africa", 100, "Tricycle", 3);
            Cyclist cyc5 = new Professional(5, "Yes", 19, 2);
            Cyclist cyc6 = new Charity(6, "Childline", 50);
            Cyclist cyc7 = new Charity(7, "Help The Heroes", 235);
            Cyclist cyc8 = new Charity(8, "Air Ambulance", 175);
            Cyclist cyc9 = new Professional(9, "Yes", 26, 5);
            Cyclist cyc10 = new Novelty(10, "Yes", "Oxfam GB", 200, "Clown Bike", 2);

            cyclist.AddCyclist(cyc1);
            cyclist.AddCyclist(cyc2);
            cyclist.AddCyclist(cyc3);
            cyclist.AddCyclist(cyc4);
            cyclist.AddCyclist(cyc5);
            cyclist.AddCyclist(cyc6);
            cyclist.AddCyclist(cyc7);
            cyclist.AddCyclist(cyc8);
            cyclist.AddCyclist(cyc9);
            cyclist.AddCyclist(cyc10);

            LoadCyclists(cyclist);
        }

        private void DisplayDetails(Cyclist cyc)
        {
            lstCyclistsTime.Items.Clear();
        }

        private void LoadCyclists(Cyclist pRace)
        {
            //populates list with array values
            int index;

            lstCompetingCyclists.Items.Clear();

            for (index = 0; index < pRace.CyclistCount; index++)
            {
                lstCompetingCyclists.Items.Add(pRace.GetCyclist(index));
            }
        }

        private void lstCompetingCyclists_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCompetingCyclists.SelectedIndex >= 0)
            {
                //selects cyclist from first list and writes out their time in other listbox
                Cyclist currentCyclist = (Cyclist)lstCompetingCyclists.SelectedItem;
                DisplayDetails(currentCyclist);
                lstCyclistsTime.Items.Add("Finish Race : " + currentCyclist.DidFinish);
                lstCyclistsTime.Items.Add("");
                lstCyclistsTime.Items.Add("Finish Time : " + currentCyclist.finishTime);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Cyclist currentCyclist = (Cyclist)lstCompetingCyclists.SelectedItem;

            //validates whether time textbox is empty when submitted
            if (txtFinishingTime.Text == "")
            {
                MessageBox.Show("Please enter a time. (HH:MM:SS)");
            }
            else
            {
                //updates cyclists time so can be viewed in list 
                currentCyclist.finishTime = txtFinishingTime.Text;
                currentCyclist.DidFinish = "Yes";

                //adds one to the amount of cyclists finished
                finishcount++;

                //writes finished cyclists into label
                lblCounter.Text = (Convert.ToString(finishcount));

                LoadCyclists(cyclist);
            }
            txtFinishingTime.Text = ("");

            DisplayDetails(currentCyclist);
        }

    }
}
