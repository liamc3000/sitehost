﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BikeRace
{
    class Novelty : Charity
    {
        //variables that hold the information
        public String bikeType;
        public int numberofWheels;

        //stores property for whether cyclist is novelty
        public String IsNovelty
        {
            get
            {
                return isNovelty;
            }
            set
            {
                isNovelty = value;
            }
        }

        //stores value for type of bike they are using
        public String BikeType
        {
            get
            {
                return bikeType;
            }
            set
            {
                bikeType = value;
            }
        }

        //stores value for number of wheels
        public int NumberWheels
        {
            get
            {
                return numberofWheels;
            }
            set
            {
                numberofWheels = value;
            }
        }

        public Novelty()
        {
            //sets all default values to nothing
            CyclistNumber = 0;
            isNovelty = "";
            charityName = "";
            amountRaised = 0;
            bikeType = "";
            numberofWheels = 0;
        }

        //sets values for each parameter
        public Novelty(int cyclistnumber, String isNovelty, String charityName, Double amountRaised, String bikeType, int numberofWheels)
        {
            this.CyclistNumber = cyclistnumber;
            this.isNovelty = isNovelty;
            this.charityName = charityName;
            this.amountRaised = amountRaised;
            this.bikeType = bikeType;
            this.numberofWheels = numberofWheels;
        }

        //writes out details from parameters
        public override string ToString()
        {
            return "Cyclist Number: " + CyclistNumber + ",   Novelty: " + isNovelty + ",   Charity Name: " + charityName + ",   Sponsorship: £" + amountRaised + ",   Bike Type: " + bikeType + ",   Number of Wheels: " + numberofWheels;
        }
    }
}
