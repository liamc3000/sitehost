﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BikeRace
{
    class Professional : Cyclist
    {
        //variables where i will store information
        public String isProfessional;
        public int age;

        //stores values for whether cyclist is professional
        public String IsProfessional
        {
            get
            {
                return isProfessional;
            }
            set
            {
                isProfessional = value;
            }
        }

        //stores values for cyclists age
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }

        //stores value for amount of races cyclists finished
        public int RacesFinished
        {
            get
            {
                return racesFinished;
            }
            set
            {
                racesFinished = value;
            }
        }

        //sets parameters as zero
        public Professional()
        {
            CyclistNumber = 0;
            isProfessional = "";
            age = 0;
            racesFinished = 0;
        }

        //sets value from the variable
        public Professional(int cyclistnumber, String isProfessional, int age, int racesFinished)
        {
            this.CyclistNumber = cyclistnumber;
            this.isProfessional = isProfessional;
            this.age = age;
            this.racesFinished = racesFinished;
        }

        //writes out information to list
        public override string ToString()
        {
            return "Cyclist Number: " + CyclistNumber + ",   Professional: " + isProfessional + ",   Age:" + age + ",   Races Finished: " + racesFinished;
        }
    }
}
