﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_2
{
    static class AppData
    {
        // Filename for application data
        public const string HANDLERLISTS = "saleslists.dat";

        //Filename for reports
        public const string BOOTSALES = "bootsales.txt";
        public const string CHARITY = "charity.txt";
        public const string NONCHARITY = "noncharity.txt";
    }
}
