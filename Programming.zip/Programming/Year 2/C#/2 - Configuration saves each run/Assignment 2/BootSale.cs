﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_2
{
    [Serializable]
    public class BootSale : BootSaleList, IDisplay
    {
        //auto-implemented properties
        public int Id { get; set; }
        public string Date { get; set; }
        public string Location { get; set; }
        public double PitchCost  { get; set; }
        public int Capacity  { get; set; }
        public Boolean Charity { get; set; }
        public string CharityName  { get; set; }
        public Boolean Catering { get; set; }
        
        //BootSale constructor
        public BootSale(int bId, string bDate, string bLocation, double bPitchCost, int bCapacity, Boolean bCharity, string bCharityName, Boolean bCatering)
        {
            Id = bId;
            Date = bDate;
            Location = bLocation;
            PitchCost = bPitchCost;
            Capacity = bCapacity;
            Charity = bCharity;
            CharityName = bCharityName;
            Catering = bCatering;
        }

        public override string ToString()
        {
            return String.Format("{0}  {1}", "ID: " + Id, "Date: " + Date);
        }

        // Return a formatted string containing all data elements of a Module
        public new string Display()
        {
            string msg;
            string CR = Environment.NewLine;

            msg = String.Format("\nBoot Sale Information: {0}", CR);
            msg += String.Format("   Id: {0} {1}", Id, CR);
            msg += String.Format("   Date: {0} {1}", Date, CR);
            msg += String.Format("   Location: {0} {1}", Location, CR);
            msg += String.Format("   Pitch Cost: £{0} {1}", PitchCost, CR);
            msg += String.Format("   Capacity: {0} {1}", Capacity, CR);
            
            if (Catering == true)
            {
                msg += String.Format("   Catering: Yes", CR);
                msg += Environment.NewLine;
            }
            else
            {
                msg += String.Format("   Catering: No", CR);
                msg += Environment.NewLine;
            }
            if (Charity == true)
            {
                msg += String.Format("   Charity: Yes", CR);
                msg += Environment.NewLine;
            }
            else
            {
                msg += String.Format("   Charity: No", CR);
                msg += Environment.NewLine;
            }
            msg += String.Format("   Charity Name: {0} {1}", CharityName, CR);
            msg += String.Format("------------------------------ ");
            
            return msg;
        }
      }
    }
