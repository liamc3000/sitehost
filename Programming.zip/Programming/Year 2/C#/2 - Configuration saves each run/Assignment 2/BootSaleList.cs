﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_2
{
    [Serializable]
    public class BootSaleList : IDisplay
    {
        private List<BootSale> bootsales;

        public BootSaleList bootSaleList { get; set; }

        public List<BootSale> ReturnList()
        {
            return bootsales;
        }

        public BootSaleList()
        {
            bootsales = new List<BootSale>();
        }

        public bool AddBootSale(BootSale bootsale)
        {
            bool success = true;
            foreach (BootSale b in bootsales)
            {
                if (b.Id == bootsale.Id)
                {
                    success = false;
                    DuplicatedIDException DuplicatedId = new DuplicatedIDException();
                    throw (DuplicatedId);
                }
            }
            if (success)
            {
                bootsales.Add(bootsale);
            }
            return success;
        }

        public int GetListSize()
        {
            return bootsales.Count();
        }

        public BootSale FindBootSale(int bId)
        {
            BootSale bootsale = null;
            foreach (BootSale b in bootsales)
            {
                if (b.Id == bId)
                {
                    bootsale = b;
                }
            }
            return bootsale;
        }

        //Content to display in textbox
        public string Display()
        {
            string msg = "";
            string CR = Environment.NewLine;

            foreach (BootSale b in bootsales)
            {
                msg += ("Car Boot Sale Info:" + CR);
                msg += String.Format("{0}  {1}", "ID: " + b.Id, b.Date, b.Location, b.PitchCost, b.Capacity, b.Catering, b.Charity, b.CharityName);
                msg += "-------------------------";
                msg += Environment.NewLine;

            }
            return msg;
        }
    }
}