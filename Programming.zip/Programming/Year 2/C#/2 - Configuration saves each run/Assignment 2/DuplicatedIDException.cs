﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_2
{
    class DuplicatedIDException : Exception
    {
        //stops duplicate id use
        private static string msg = "ID is already in use.";
        public DuplicatedIDException() : base("Error: " + msg)
        {

        }
    }
}
