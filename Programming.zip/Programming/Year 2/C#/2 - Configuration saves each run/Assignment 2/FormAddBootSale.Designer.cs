﻿namespace Assignment_2
{
    partial class FormAddBootSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPitchcost = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btbCancel = new System.Windows.Forms.Button();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();
            this.lblCapacity = new System.Windows.Forms.Label();
            this.lblCharityName = new System.Windows.Forms.Label();
            this.lblCatering = new System.Windows.Forms.Label();
            this.txtCharityName = new System.Windows.Forms.TextBox();
            this.lblCharity = new System.Windows.Forms.Label();
            this.grpCharity = new System.Windows.Forms.GroupBox();
            this.rdoCharityNo = new System.Windows.Forms.RadioButton();
            this.rdoCharityYes = new System.Windows.Forms.RadioButton();
            this.grpCatering = new System.Windows.Forms.GroupBox();
            this.rdoCateringNo = new System.Windows.Forms.RadioButton();
            this.rdoCateringYes = new System.Windows.Forms.RadioButton();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.numId = new System.Windows.Forms.NumericUpDown();
            this.numPitchCost = new System.Windows.Forms.NumericUpDown();
            this.numCapacity = new System.Windows.Forms.NumericUpDown();
            this.grpCharity.SuspendLayout();
            this.grpCatering.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPitchCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapacity)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPitchcost
            // 
            this.lblPitchcost.Location = new System.Drawing.Point(10, 93);
            this.lblPitchcost.Name = "lblPitchcost";
            this.lblPitchcost.Size = new System.Drawing.Size(78, 16);
            this.lblPitchcost.TabIndex = 18;
            this.lblPitchcost.Text = "Pitch Cost (£):";
            this.lblPitchcost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(13, 163);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 17;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btbCancel
            // 
            this.btbCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btbCancel.Location = new System.Drawing.Point(121, 163);
            this.btbCancel.Name = "btbCancel";
            this.btbCancel.Size = new System.Drawing.Size(75, 23);
            this.btbCancel.TabIndex = 16;
            this.btbCancel.Text = "Cancel";
            this.btbCancel.UseVisualStyleBackColor = true;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(96, 64);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(127, 20);
            this.txtLocation.TabIndex = 15;
            // 
            // lblLocation
            // 
            this.lblLocation.Location = new System.Drawing.Point(10, 65);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(55, 16);
            this.lblLocation.TabIndex = 14;
            this.lblLocation.Text = "Location:";
            this.lblLocation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDate
            // 
            this.lblDate.Location = new System.Drawing.Point(10, 41);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(42, 16);
            this.lblDate.TabIndex = 12;
            this.lblDate.Text = "Date:";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblId
            // 
            this.lblId.Location = new System.Drawing.Point(10, 15);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(42, 16);
            this.lblId.TabIndex = 10;
            this.lblId.Text = "Id: ";
            this.lblId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCapacity
            // 
            this.lblCapacity.Location = new System.Drawing.Point(10, 117);
            this.lblCapacity.Name = "lblCapacity";
            this.lblCapacity.Size = new System.Drawing.Size(78, 16);
            this.lblCapacity.TabIndex = 20;
            this.lblCapacity.Text = "Capacity:";
            this.lblCapacity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCharityName
            // 
            this.lblCharityName.Location = new System.Drawing.Point(237, 112);
            this.lblCharityName.Name = "lblCharityName";
            this.lblCharityName.Size = new System.Drawing.Size(78, 16);
            this.lblCharityName.TabIndex = 21;
            this.lblCharityName.Text = "Charity Name:";
            this.lblCharityName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCatering
            // 
            this.lblCatering.Location = new System.Drawing.Point(237, 19);
            this.lblCatering.Name = "lblCatering";
            this.lblCatering.Size = new System.Drawing.Size(76, 16);
            this.lblCatering.TabIndex = 22;
            this.lblCatering.Text = "Catering:";
            this.lblCatering.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCharityName
            // 
            this.txtCharityName.Location = new System.Drawing.Point(323, 111);
            this.txtCharityName.Name = "txtCharityName";
            this.txtCharityName.Size = new System.Drawing.Size(127, 20);
            this.txtCharityName.TabIndex = 24;
            // 
            // lblCharity
            // 
            this.lblCharity.Location = new System.Drawing.Point(237, 74);
            this.lblCharity.Name = "lblCharity";
            this.lblCharity.Size = new System.Drawing.Size(72, 16);
            this.lblCharity.TabIndex = 29;
            this.lblCharity.Text = "Charity:";
            this.lblCharity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // grpCharity
            // 
            this.grpCharity.Controls.Add(this.rdoCharityNo);
            this.grpCharity.Controls.Add(this.rdoCharityYes);
            this.grpCharity.Location = new System.Drawing.Point(323, 55);
            this.grpCharity.Name = "grpCharity";
            this.grpCharity.Size = new System.Drawing.Size(107, 50);
            this.grpCharity.TabIndex = 30;
            this.grpCharity.TabStop = false;
            // 
            // rdoCharityNo
            // 
            this.rdoCharityNo.AutoSize = true;
            this.rdoCharityNo.Location = new System.Drawing.Point(55, 19);
            this.rdoCharityNo.Name = "rdoCharityNo";
            this.rdoCharityNo.Size = new System.Drawing.Size(29, 14);
            this.rdoCharityNo.TabIndex = 33;
            this.rdoCharityNo.TabStop = true;
            this.rdoCharityNo.Text = "No";
            this.rdoCharityNo.UseVisualStyleBackColor = true;
            this.rdoCharityNo.CheckedChanged += new System.EventHandler(this.rdoCharityNo_CheckedChanged);
            // 
            // rdoCharityYes
            // 
            this.rdoCharityYes.AutoSize = true;
            this.rdoCharityYes.Location = new System.Drawing.Point(6, 19);
            this.rdoCharityYes.Name = "rdoCharityYes";
            this.rdoCharityYes.Size = new System.Drawing.Size(32, 14);
            this.rdoCharityYes.TabIndex = 32;
            this.rdoCharityYes.TabStop = true;
            this.rdoCharityYes.Text = "Yes";
            this.rdoCharityYes.UseVisualStyleBackColor = true;
            this.rdoCharityYes.CheckedChanged += new System.EventHandler(this.rdoCharityYes_CheckedChanged);
            // 
            // grpCatering
            // 
            this.grpCatering.Controls.Add(this.rdoCateringNo);
            this.grpCatering.Controls.Add(this.rdoCateringYes);
            this.grpCatering.Location = new System.Drawing.Point(323, -1);
            this.grpCatering.Name = "grpCatering";
            this.grpCatering.Size = new System.Drawing.Size(107, 50);
            this.grpCatering.TabIndex = 31;
            this.grpCatering.TabStop = false;
            // 
            // rdoCateringNo
            // 
            this.rdoCateringNo.AutoSize = true;
            this.rdoCateringNo.Location = new System.Drawing.Point(55, 19);
            this.rdoCateringNo.Name = "rdoCateringNo";
            this.rdoCateringNo.Size = new System.Drawing.Size(29, 14);
            this.rdoCateringNo.TabIndex = 35;
            this.rdoCateringNo.TabStop = true;
            this.rdoCateringNo.Text = "No";
            this.rdoCateringNo.UseVisualStyleBackColor = true;
            this.rdoCateringNo.CheckedChanged += new System.EventHandler(this.rdoCateringNo_CheckedChanged);
            // 
            // rdoCateringYes
            // 
            this.rdoCateringYes.AutoSize = true;
            this.rdoCateringYes.Location = new System.Drawing.Point(6, 19);
            this.rdoCateringYes.Name = "rdoCateringYes";
            this.rdoCateringYes.Size = new System.Drawing.Size(32, 14);
            this.rdoCateringYes.TabIndex = 34;
            this.rdoCateringYes.TabStop = true;
            this.rdoCateringYes.Text = "Yes";
            this.rdoCateringYes.UseVisualStyleBackColor = true;
            this.rdoCateringYes.CheckedChanged += new System.EventHandler(this.rdoCateringYes_CheckedChanged);
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(98, 41);
            this.dtpDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(125, 20);
            this.dtpDate.TabIndex = 32;
            // 
            // numId
            // 
            this.numId.Location = new System.Drawing.Point(98, 15);
            this.numId.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numId.Name = "numId";
            this.numId.Size = new System.Drawing.Size(75, 20);
            this.numId.TabIndex = 33;
            // 
            // numPitchCost
            // 
            this.numPitchCost.DecimalPlaces = 2;
            this.numPitchCost.Location = new System.Drawing.Point(96, 93);
            this.numPitchCost.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numPitchCost.Name = "numPitchCost";
            this.numPitchCost.Size = new System.Drawing.Size(75, 20);
            this.numPitchCost.TabIndex = 34;
            // 
            // numCapacity
            // 
            this.numCapacity.Location = new System.Drawing.Point(96, 117);
            this.numCapacity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.numCapacity.Name = "numCapacity";
            this.numCapacity.Size = new System.Drawing.Size(75, 20);
            this.numCapacity.TabIndex = 35;
            // 
            // FormAddBootSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 207);
            this.Controls.Add(this.numCapacity);
            this.Controls.Add(this.numPitchCost);
            this.Controls.Add(this.numId);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.grpCatering);
            this.Controls.Add(this.grpCharity);
            this.Controls.Add(this.lblCharity);
            this.Controls.Add(this.txtCharityName);
            this.Controls.Add(this.lblCatering);
            this.Controls.Add(this.lblCharityName);
            this.Controls.Add(this.lblCapacity);
            this.Controls.Add(this.lblPitchcost);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btbCancel);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblId);
            this.Name = "FormAddBootSale";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Boot Sale";
            this.Load += new System.EventHandler(this.FormAddBootSale_Load);
            this.grpCharity.ResumeLayout(false);
            this.grpCharity.PerformLayout();
            this.grpCatering.ResumeLayout(false);
            this.grpCatering.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPitchCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapacity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPitchcost;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btbCancel;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblCapacity;
        private System.Windows.Forms.Label lblCharityName;
        private System.Windows.Forms.Label lblCatering;
        private System.Windows.Forms.TextBox txtCharityName;
        private System.Windows.Forms.Label lblCharity;
        private System.Windows.Forms.GroupBox grpCharity;
        private System.Windows.Forms.RadioButton rdoCharityNo;
        private System.Windows.Forms.RadioButton rdoCharityYes;
        private System.Windows.Forms.GroupBox grpCatering;
        private System.Windows.Forms.RadioButton rdoCateringNo;
        private System.Windows.Forms.RadioButton rdoCateringYes;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.NumericUpDown numId;
        private System.Windows.Forms.NumericUpDown numPitchCost;
        private System.Windows.Forms.NumericUpDown numCapacity;
    }
}