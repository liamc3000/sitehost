﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assignment_2
{
    
    public partial class FormAddBootSale : Form
    {
        bool Catering;
        bool Charity;

        public FormAddBootSale()
        {
            InitializeComponent();
        }

        private void FormAddBootSale_Load(object sender, EventArgs e)
        {

        }

        //makes sure fields not blank
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtLocation.Text == "" || txtCharityName.Text == "")
            {
                MessageBox.Show("Please make sure that all of the fields are filled correctly.");
            }
            else
            {
                GetBootSaleData();
            }
        }

        //retrieves data from fields
        public BootSale GetBootSaleData()
        {
            BootSale newBootSale = new BootSale(Convert.ToInt32(numId.Value), dtpDate.Text, txtLocation.Text, Convert.ToDouble(numPitchCost.Value), Convert.ToInt32(numCapacity.Value), Charity, txtCharityName.Text, Catering);
            return newBootSale;
        }

        //converts selection to bool
        private void rdoCateringYes_CheckedChanged(object sender, EventArgs e)
        {
            Catering = true;
        }

        //converts selection to bool
        private void rdoCateringNo_CheckedChanged(object sender, EventArgs e)
        {
            Catering = false;
        }

        //converts selection to bool
        private void rdoCharityYes_CheckedChanged(object sender, EventArgs e)
        {
            Charity = true;
            txtCharityName.ReadOnly = false;
            txtCharityName.Text = "";
        }

        //converts selection to bool & hides option
        private void rdoCharityNo_CheckedChanged(object sender, EventArgs e)
        {
            Charity = false;
            txtCharityName.ReadOnly = true;
            txtCharityName.Text = "N/A";
        }
    }
}
