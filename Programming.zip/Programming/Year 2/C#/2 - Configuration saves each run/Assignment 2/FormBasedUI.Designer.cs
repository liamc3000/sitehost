﻿namespace Assignment_2
{
    partial class FormBasedUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstBootSales = new System.Windows.Forms.ListBox();
            this.btnAddSale = new System.Windows.Forms.Button();
            this.btnSaveSales = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtBootSaleInfo = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allSalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.charitySalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nonCharitySalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDelete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstBootSales
            // 
            this.lstBootSales.FormattingEnabled = true;
            this.lstBootSales.Location = new System.Drawing.Point(99, 27);
            this.lstBootSales.Name = "lstBootSales";
            this.lstBootSales.Size = new System.Drawing.Size(202, 238);
            this.lstBootSales.TabIndex = 1;
            this.lstBootSales.SelectedIndexChanged += new System.EventHandler(this.lstBootSales_SelectedIndexChanged);
            // 
            // btnAddSale
            // 
            this.btnAddSale.Location = new System.Drawing.Point(12, 27);
            this.btnAddSale.Name = "btnAddSale";
            this.btnAddSale.Size = new System.Drawing.Size(82, 39);
            this.btnAddSale.TabIndex = 3;
            this.btnAddSale.Text = "Add Sale";
            this.btnAddSale.UseVisualStyleBackColor = true;
            this.btnAddSale.Click += new System.EventHandler(this.btnAddSale_Click);
            // 
            // btnSaveSales
            // 
            this.btnSaveSales.Location = new System.Drawing.Point(12, 115);
            this.btnSaveSales.Name = "btnSaveSales";
            this.btnSaveSales.Size = new System.Drawing.Size(82, 39);
            this.btnSaveSales.TabIndex = 6;
            this.btnSaveSales.Text = "Save";
            this.btnSaveSales.UseVisualStyleBackColor = true;
            this.btnSaveSales.Click += new System.EventHandler(this.btnSaveSales_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(11, 226);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(82, 39);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtBootSaleInfo
            // 
            this.txtBootSaleInfo.Location = new System.Drawing.Point(307, 28);
            this.txtBootSaleInfo.Multiline = true;
            this.txtBootSaleInfo.Name = "txtBootSaleInfo";
            this.txtBootSaleInfo.ReadOnly = true;
            this.txtBootSaleInfo.Size = new System.Drawing.Size(202, 147);
            this.txtBootSaleInfo.TabIndex = 8;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(527, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allSalesToolStripMenuItem,
            this.charitySalesToolStripMenuItem,
            this.nonCharitySalesToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // allSalesToolStripMenuItem
            // 
            this.allSalesToolStripMenuItem.Name = "allSalesToolStripMenuItem";
            this.allSalesToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.allSalesToolStripMenuItem.Text = "All Sales";
            this.allSalesToolStripMenuItem.Click += new System.EventHandler(this.allSalesToolStripMenuItem_Click);
            // 
            // charitySalesToolStripMenuItem
            // 
            this.charitySalesToolStripMenuItem.Name = "charitySalesToolStripMenuItem";
            this.charitySalesToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.charitySalesToolStripMenuItem.Text = "Charity Sales";
            this.charitySalesToolStripMenuItem.Click += new System.EventHandler(this.charitySalesToolStripMenuItem_Click);
            // 
            // nonCharitySalesToolStripMenuItem
            // 
            this.nonCharitySalesToolStripMenuItem.Name = "nonCharitySalesToolStripMenuItem";
            this.nonCharitySalesToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.nonCharitySalesToolStripMenuItem.Text = "Non Charity Sales ";
            this.nonCharitySalesToolStripMenuItem.Click += new System.EventHandler(this.nonCharitySalesToolStripMenuItem_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(12, 71);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(82, 39);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // FormBasedUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 278);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtBootSaleInfo);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSaveSales);
            this.Controls.Add(this.btnAddSale);
            this.Controls.Add(this.lstBootSales);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormBasedUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Boot Sale Manager";
            this.Load += new System.EventHandler(this.FormBasedUI_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstBootSales;
        private System.Windows.Forms.Button btnAddSale;
        private System.Windows.Forms.Button btnSaveSales;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtBootSaleInfo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allSalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem charitySalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nonCharitySalesToolStripMenuItem;
        private System.Windows.Forms.Button btnDelete;
    }
}

