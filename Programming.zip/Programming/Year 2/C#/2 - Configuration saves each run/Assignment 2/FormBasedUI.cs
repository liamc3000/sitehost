﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Assignment_2
{
    public partial class FormBasedUI : Form, IUserInterface
    {
        BootSaleList bootsalelist = new BootSaleList();
        BootSaleList listFile;
        SerializeFileHandler serializeFileHandler;
        TextReportGenerator textReportGenerator;

        public FormBasedUI(BootSaleList salelist, BootSaleList lists, SerializeFileHandler sfh, TextReportGenerator trg)
        {
            InitializeComponent();
            bootsalelist = salelist;
            listFile = lists;
            serializeFileHandler = sfh;
            textReportGenerator = trg;
        }

        private void FormBasedUI_Load(object sender, EventArgs e)
        {
            //GenerateTestData();

            //SaveSales();

            LoadSales();

            DisplayAllBootSales();
        }

        public void GenerateTestData()
        {
            // Creates some temporary data
            BootSale b1 = new BootSale(1, "20 February 2013", "Sunderland", 10.00, 100, true, "Red Cross", true);
            BootSale b2 = new BootSale(2, "21 March 2013", "Newcastle", 15.00, 200, false, "N/A", true);

            bootsalelist.AddBootSale(b1);
            bootsalelist.AddBootSale(b2);
        }
        
        #region  ############### Buttons #################

        private void btnExit_Click(object sender, EventArgs e)
        {
            //runs save before close
            DialogResult dr = MessageBox.Show("Do you want to save the data file?",
                            "Save data", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                SaveSales();
            }

            Application.Exit();
        }

        private void btnAddSale_Click(object sender, EventArgs e)
        {
            AddBootSale();
            DisplayAllBootSales();
        }

        private void btnSaveSales_Click(object sender, EventArgs e)
        {
            SaveSales();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteSale();
        }

        #endregion

        #region ############### ToolStripMenu Items #################

        private void allSalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AllSalesReport();
            DisplayAllBootSales();
        }

        private void charitySalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CharitySalesReport();
            DisplayAllBootSales();
        }

        private void nonCharitySalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NonCharitySalesReport();
            DisplayAllBootSales();
        }

        #endregion

        #region ############### Listbox Handling #################

        private void lstBootSales_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplaySale();
        }

        #endregion

        #region ############### Methods #################

        public void AddBootSale()
        {
            //opens add sale page and prepares code
            try
            {
                FormAddBootSale addBootSale = new FormAddBootSale();
                if (addBootSale.ShowDialog() == DialogResult.OK)
                {
                    BootSale newBootSale = addBootSale.GetBootSaleData();

                    bootsalelist.AddBootSale(newBootSale);

                    txtBootSaleInfo.Clear();
                    txtBootSaleInfo.Text = newBootSale.Display();
                }
            }
            catch (DuplicatedIDException DuplicatedId)
            {
                MessageBox.Show(DuplicatedId.Message, "Error: ");
            }
        }

        public void DisplaySale()
        {
            if (lstBootSales.SelectedItem != null)
            {
                BootSale bootsaleList = (BootSale)lstBootSales.SelectedItem;
                txtBootSaleInfo.Text = bootsaleList.Display();
            }
            else
            {
                txtBootSaleInfo.Text = " ";
            }
        }

        public void DisplayAllBootSales()
        {
            //refreshes list
            lstBootSales.Items.Clear();
            txtBootSaleInfo.Clear();

            List<BootSale> bootsales = bootsalelist.ReturnList();

            foreach (BootSale b in bootsales)
            {
                lstBootSales.Items.Add(b);
            }
        }

        public void DeleteSale()
        {
            //removes selected item from list
            foreach (BootSale b in lstBootSales.SelectedItems.OfType<BootSale>().ToArray())
            {
                bootsalelist.ReturnList().Remove(b);
                lstBootSales.Items.Remove(b);

                DisplayAllBootSales();
            }
        }

        public void LoadSales()
        {
            //retrieves data from file
            try
            {
                listFile = serializeFileHandler.ReadListFromFile(AppData.HANDLERLISTS);

                bootsalelist = listFile.bootSaleList;
                MessageBox.Show("Sales List data file has been loaded");
                Console.WriteLine();
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Sales List data file has not been loaded");
                Console.ReadKey();
            }
        }

        public void SaveSales()
        {
            //overwrites current saved list
            listFile.bootSaleList = bootsalelist;

            serializeFileHandler.WriteListToFile(listFile, AppData.HANDLERLISTS);

            MessageBox.Show("Car Boot Sale Data has been saved.");
        }

        public void AllSalesReport()
        {
            //outputs report for all data
            List<BootSale> bootsales = bootsalelist.ReturnList();
            bootsales.Sort(delegate(BootSale bs1, BootSale bs2)
            {
                return Comparer<int>.Default.Compare(bs1.Id, bs2.Id);
            });
            textReportGenerator.GenerateSortedReport(bootsales, AppData.BOOTSALES);
            MessageBox.Show("Car Boot Sales written to report file: " + AppData.BOOTSALES);
        }

        public void NonCharitySalesReport()
        {
            //outputs report for all non charity data
            List<BootSale> bootsales = bootsalelist.ReturnList();
            bootsales.Sort(delegate(BootSale bs1, BootSale bs2)
            {
                return Comparer<int>.Default.Compare(bs1.Id, bs2.Id);
            });
            textReportGenerator.GenerateNoCharityReport(bootsales, AppData.NONCHARITY);
            MessageBox.Show("Charity Car Boot Sales written to report file: " + AppData.NONCHARITY);
        }

        public void CharitySalesReport()
        {
            //outputs report for all charity sales
            List<BootSale> bootsales = bootsalelist.ReturnList();
            bootsales.Sort(delegate(BootSale bs1, BootSale bs2)
            {
                return Comparer<int>.Default.Compare(bs1.Id, bs2.Id);
            });
            textReportGenerator.GenerateCharityReport(bootsales, AppData.CHARITY);
            MessageBox.Show("Charity Car Boot Sales written to report file: " + AppData.CHARITY);
        }

        #endregion

        #region ###############  #################


        #endregion

    }
}
