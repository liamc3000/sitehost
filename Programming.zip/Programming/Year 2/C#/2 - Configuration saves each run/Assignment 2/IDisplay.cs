﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_2
{
    public interface IDisplay
    {
        //displays lists on the interface
        string Display();
    }
}
