﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_2
{
    public interface IUserInterface
    {
        //allows methods to run on form
        void DeleteSale();
        void AddBootSale();
        void DisplaySale();
        void DisplayAllBootSales();
        void SaveSales();
        void LoadSales();
        void AllSalesReport();
        void CharitySalesReport();
        void NonCharitySalesReport();
    }
}
