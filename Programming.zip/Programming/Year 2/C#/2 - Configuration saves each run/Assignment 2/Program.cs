﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Assignment_2
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            BootSaleList salelist = new BootSaleList();

            BootSaleList lists = new BootSaleList();

            SerializeFileHandler sfh = new SerializeFileHandler();

            TextReportGenerator trg = new TextReportGenerator();
                        
            Application.Run(new FormBasedUI(salelist, lists, sfh, trg));
        }
    }
}
