﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Assignment_2
{
    public class SerializeFileHandler
    {

        public void WriteListToFile(BootSaleList lists, string filePath)
        {
            FileStream outFile;
            BinaryFormatter bFormatter = new BinaryFormatter();

            // Ppen file for output
            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            
            // Output object to file via serialization
            bFormatter.Serialize(outFile, lists);

            // Close file
            outFile.Close();
         }

        public BootSaleList ReadListFromFile(String filePath)
        {
            FileStream inFile;
            BinaryFormatter bFormatter = new BinaryFormatter();
            BootSaleList list = new BootSaleList();

            // Open file for input
            inFile = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            // Obtain objects from file via serialization
            list = (BootSaleList)bFormatter.Deserialize(inFile);

            inFile.Close();
            return list;
        }
    }
}
