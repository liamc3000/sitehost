﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Assignment_2
{
    public class TextReportGenerator
    {
        public void GenerateSortedReport<T>(List<T> aList, string filePath) where T : IDisplay
        {
            //outputs all data sorted in order by id
            FileStream outFile;
            StreamWriter writer;

            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            writer = new StreamWriter(outFile);

            foreach (T obj in aList)
            {
                writer.WriteLine(obj.Display());
            }

            writer.Close();
            outFile.Close();
        }

        public void GenerateCharityReport(List<BootSale> charitylist, string filePath)
        {
            //outputs all data sorted by whether charity
            FileStream outFile;
            StreamWriter writer;

            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            writer = new StreamWriter(outFile);

            foreach (BootSale obj in charitylist)
            {
                if (obj.Charity == true)
                {
                    writer.WriteLine(obj.Display());
                }
            }

            writer.Close();
            outFile.Close();
        }

        public void GenerateNoCharityReport(List<BootSale> charitylist, string filePath)
        {
            //outputs all data sorted by whether charity
            FileStream outFile;
            StreamWriter writer;

            outFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            writer = new StreamWriter(outFile);

            foreach (BootSale obj in charitylist)
            {
                if (obj.Charity == false)
                {
                    writer.WriteLine(obj.Display());
                }
            }

            writer.Close();
            outFile.Close();
        }
    }
}
