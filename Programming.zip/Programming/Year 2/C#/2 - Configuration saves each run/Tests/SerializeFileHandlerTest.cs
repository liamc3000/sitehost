﻿using Assignment_2;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Tests
{
    /// <summary>
    ///This is a test class for SerializeFileHandlerTest and is intended
    ///to contain all SerializeFileHandlerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SerializeFileHandlerTest
    {
        /// <summary>
        ///A test for ReadListFromFile
        ///</summary>
        [TestMethod()]
        public void ReadListFromFileTest()
        {
            List<BootSale> testList = new List<BootSale>();
            testList.Add(new BootSale(1, "20 February 2013", "Sunderland", 10.00, 100, true, "Red Cross", true));
            testList.Add(new BootSale(2, "21 March 2013", "Newcastle", 15.00, 200, false, "N/A", true));

            var expectedResult = true;
            var actualResult = false;

            BinaryFormatter bFormatter = new BinaryFormatter();
            FileStream outFile = new FileStream("saleslists.dat", FileMode.Create, FileAccess.Write);
            bFormatter.Serialize(outFile, testList);
            outFile.Flush();
            outFile.Close();

            bFormatter = new BinaryFormatter();
            FileStream inFile = new FileStream("saleslists.dat", FileMode.Open, FileAccess.Read);
            testList = (List<BootSale>)bFormatter.Deserialize(inFile);
            inFile.Flush();
            inFile.Close();

            if (testList.Count == 2)
            {
                actualResult = true;
            }
            Assert.AreEqual(expectedResult, actualResult);
        }
    }
}
