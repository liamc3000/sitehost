﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project
{
    class GlobalData
    {  
        //Home data values
        public static int TotalGirls = 0;
        public static int TotalBoys = 0;
        public static double AttendanceAverage = 0;
        public static double AttendanceAverage7 = 0;
        public static double AttendanceAverage8 = 0;
        public static double AttendanceAverage9 = 0;
        public static double AttendanceAverage10 = 0;
        public static double AttendanceAverage11 = 0;
        public static double AttendanceAverageBoys = 0;
        public static double AttendanceAverageGirls = 0;

        public static double EffortAverage = 0;
        public static double EffortAverage7 = 0;
        public static double EffortAverage8 = 0;
        public static double EffortAverage9 = 0;
        public static double EffortAverage10 = 0;
        public static double EffortAverage11 = 0;
        public static double EffortAverageBoys = 0;
        public static double EffortAverageGirls = 0;

        public static double AcademicAverage = 0;
        public static double AcademicAverage7 = 0;
        public static double AcademicAverage8 = 0;
        public static double AcademicAverage9 = 0;
        public static double AcademicAverage10 = 0;
        public static double AcademicAverage11 = 0;
        public static double AcademicAverageBoys = 0;
        public static double AcademicAverageGirls = 0;

        //Student data values
        public static int TotalRows = 0;
        public static string UPNNo;
        public static int SearchedStudent = 0;

        //Chart data values
        public static int BronzeAttendance = 0;
        public static int BronzeEffort = 0;
        public static int BronzeAcademic = 0;
        public static int AttendanceEffortSilver = 0;
        public static int AttendanceAcademicSilver = 0;
        public static int EffortAcademicSilver = 0;
        public static int GoldStudents = 0;
        public static int Bronze = 0;
        public static int Silver = 0;
        public static int Gold = 0;

        public static string[] StudentOutput;

        //stores cell data publically
        public static double[] CellA;
        public static double[] CellB;
        public static double[] CellC;
        public static string[] CellD;
        public static string[] CellE;
        public static string[] CellF;
        public static string[] CellG;
        public static string[] CellH;
        public static int[] CellI;
        public static string[] CellJ;
        public static string[] CellK;
        public static string[] CellL;
        public static string[] CellM;
        public static string[] CellN;
        public static double[] CellO;
        public static string[] CellP;
        public static string[] CellQ;
        public static string[] CellR;
        public static string[] CellS;
        public static string[] CellT;
        public static string[] CellU;
        public static string[] CellV;
        public static string[] CellW;
        public static int[] CellX;
        public static string[] CellY;
        public static int[] CellZ;
        public static int[] CellAA;
        public static string[] CellAB;
        public static string[] CellAC;
        
    }
}
