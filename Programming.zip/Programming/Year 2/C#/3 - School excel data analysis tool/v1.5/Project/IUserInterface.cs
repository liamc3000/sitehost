﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project
{
    public interface IUserInterface
    {
        //allows methods to run on form
        void ReadData();
        void ChartData();
        void SearchStudent();
        void UpdateSearchInfo();
        void PopulateDropDowns();
        void HomeValues();
        void UpdateHomeInfo();
        void ChartDataYearSort();
        void ChartDataGenderSort();
        void ChartDataHouseSort();
        void ChartDataYearGenderSort();
        void ChartDataYearHouseSort();
        void ChartDataGenderHouseSort();

        void PrintOutput();
        void DisplayOutput();
    }
}
