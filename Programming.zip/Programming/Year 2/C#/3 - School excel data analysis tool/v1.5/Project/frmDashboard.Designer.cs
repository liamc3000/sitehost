﻿namespace Project
{
    partial class frmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashboard));
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.reCharts = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.recSingle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.recHome = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.Topbar = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.label1 = new System.Windows.Forms.Label();
            this.btnImport = new System.Windows.Forms.Button();
            this.tabDashboard = new System.Windows.Forms.TabControl();
            this.tabHome = new System.Windows.Forms.TabPage();
            this.grpHome = new System.Windows.Forms.GroupBox();
            this.lblAverageAcademicGirls = new System.Windows.Forms.Label();
            this.lblAverageAcademicBoys = new System.Windows.Forms.Label();
            this.lblAverageAcademic11 = new System.Windows.Forms.Label();
            this.lblAverageAcademic10 = new System.Windows.Forms.Label();
            this.lblAverageAcademic9 = new System.Windows.Forms.Label();
            this.lblAverageAcademic8 = new System.Windows.Forms.Label();
            this.lblAverageAcademic7 = new System.Windows.Forms.Label();
            this.lblAverageEffortGirls = new System.Windows.Forms.Label();
            this.lblAverageEffortBoys = new System.Windows.Forms.Label();
            this.lblAverageEffort11 = new System.Windows.Forms.Label();
            this.lblAverageEffort10 = new System.Windows.Forms.Label();
            this.lblAverageEffort9 = new System.Windows.Forms.Label();
            this.lblAverageEffort8 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.lblAverageEffort7 = new System.Windows.Forms.Label();
            this.lblAverageAttendanceGirls = new System.Windows.Forms.Label();
            this.lblAverageAttendanceBoys = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.lblAverageAttendance11 = new System.Windows.Forms.Label();
            this.lblAverageAttendance10 = new System.Windows.Forms.Label();
            this.lblAverageAttendance9 = new System.Windows.Forms.Label();
            this.lblAverageAttendance8 = new System.Windows.Forms.Label();
            this.lblTotalGirls = new System.Windows.Forms.Label();
            this.lblTotalBoys = new System.Windows.Forms.Label();
            this.lblSumStudents = new System.Windows.Forms.Label();
            this.lblAverageAttendance7 = new System.Windows.Forms.Label();
            this.lblAverageAcademic = new System.Windows.Forms.Label();
            this.lblAverageEffort = new System.Windows.Forms.Label();
            this.lblAverageAttendance = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblPercengirls = new System.Windows.Forms.Label();
            this.lblPercenboys = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabStudents = new System.Windows.Forms.TabPage();
            this.lblWrongUpn = new System.Windows.Forms.Label();
            this.grpStudent = new System.Windows.Forms.GroupBox();
            this.lblAttendanceValue = new System.Windows.Forms.Label();
            this.lblEffortValue = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.lblAcademicValue = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblPostCodeValue = new System.Windows.Forms.Label();
            this.lblYearValue = new System.Windows.Forms.Label();
            this.lblHouseValue = new System.Windows.Forms.Label();
            this.lblRegistrationValue = new System.Windows.Forms.Label();
            this.lblUpnNumberValue = new System.Windows.Forms.Label();
            this.lblAdNumberValue = new System.Windows.Forms.Label();
            this.lblFreeMealValue = new System.Windows.Forms.Label();
            this.lblSenValue = new System.Windows.Forms.Label();
            this.lblLeaValue = new System.Windows.Forms.Label();
            this.lblQuickNoteValue = new System.Windows.Forms.Label();
            this.lblLanguageValue = new System.Windows.Forms.Label();
            this.lblEthnicityValue = new System.Windows.Forms.Label();
            this.lblGenderValue = new System.Windows.Forms.Label();
            this.lblSurnameValue = new System.Windows.Forms.Label();
            this.lblForenameValue = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.tabCharts = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.label56 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.cboFilter = new System.Windows.Forms.ComboBox();
            this.grpSort = new System.Windows.Forms.GroupBox();
            this.chkHouseEnable = new System.Windows.Forms.CheckBox();
            this.chkGenderEnable = new System.Windows.Forms.CheckBox();
            this.chkYearEnable = new System.Windows.Forms.CheckBox();
            this.btnAddSorts = new System.Windows.Forms.Button();
            this.cboHouse = new System.Windows.Forms.ComboBox();
            this.cboYear = new System.Windows.Forms.ComboBox();
            this.cboGender = new System.Windows.Forms.ComboBox();
            this.btnPrint = new System.Windows.Forms.Button();
            this.lblTotalStudents = new System.Windows.Forms.Label();
            this.lblEffortAcademicSilver = new System.Windows.Forms.Label();
            this.lblAttendanceAcademicSilver = new System.Windows.Forms.Label();
            this.cboAttendance = new System.Windows.Forms.ComboBox();
            this.lblEffort = new System.Windows.Forms.Label();
            this.cboAcademic = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.cboEffort = new System.Windows.Forms.ComboBox();
            this.lblGold = new System.Windows.Forms.Label();
            this.lblAttendanceEffortSilver = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.lblAcademic = new System.Windows.Forms.Label();
            this.lblAttendance = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.picVennDiagram = new System.Windows.Forms.PictureBox();
            this.lblHome = new System.Windows.Forms.LinkLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.lblCharts = new System.Windows.Forms.LinkLabel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblStudents = new System.Windows.Forms.LinkLabel();
            this.lblLoadStatus = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnClear = new System.Windows.Forms.Button();
            this.tabDashboard.SuspendLayout();
            this.tabHome.SuspendLayout();
            this.grpHome.SuspendLayout();
            this.tabStudents.SuspendLayout();
            this.grpStudent.SuspendLayout();
            this.tabCharts.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpSort.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picVennDiagram)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.reCharts,
            this.rectangleShape1,
            this.recSingle,
            this.recHome,
            this.Topbar});
            this.shapeContainer1.Size = new System.Drawing.Size(853, 501);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // reCharts
            // 
            this.reCharts.BackColor = System.Drawing.SystemColors.Control;
            this.reCharts.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.reCharts.Location = new System.Drawing.Point(391, 100);
            this.reCharts.Name = "reCharts";
            this.reCharts.Size = new System.Drawing.Size(125, 34);
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.Color.Maroon;
            this.rectangleShape1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.rectangleShape1.Location = new System.Drawing.Point(364, 233);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(125, 34);
            // 
            // recSingle
            // 
            this.recSingle.BackColor = System.Drawing.SystemColors.Control;
            this.recSingle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.recSingle.Location = new System.Drawing.Point(266, 100);
            this.recSingle.Name = "recSingle";
            this.recSingle.Size = new System.Drawing.Size(125, 34);
            // 
            // recHome
            // 
            this.recHome.BackColor = System.Drawing.SystemColors.Control;
            this.recHome.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.recHome.Location = new System.Drawing.Point(141, 100);
            this.recHome.Name = "recHome";
            this.recHome.Size = new System.Drawing.Size(125, 34);
            // 
            // Topbar
            // 
            this.Topbar.Enabled = false;
            this.Topbar.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.Topbar.FillGradientColor = System.Drawing.Color.DarkGray;
            this.Topbar.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.Topbar.Location = new System.Drawing.Point(-4, 0);
            this.Topbar.Name = "Topbar";
            this.Topbar.Size = new System.Drawing.Size(857, 134);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(136, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(430, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "Dene Community School";
            // 
            // btnImport
            // 
            this.btnImport.Location = new System.Drawing.Point(742, 3);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(108, 27);
            this.btnImport.TabIndex = 3;
            this.btnImport.Text = "Import Spreadsheet";
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // tabDashboard
            // 
            this.tabDashboard.Controls.Add(this.tabHome);
            this.tabDashboard.Controls.Add(this.tabStudents);
            this.tabDashboard.Controls.Add(this.tabCharts);
            this.tabDashboard.Enabled = false;
            this.tabDashboard.Location = new System.Drawing.Point(0, 134);
            this.tabDashboard.Name = "tabDashboard";
            this.tabDashboard.SelectedIndex = 0;
            this.tabDashboard.Size = new System.Drawing.Size(856, 377);
            this.tabDashboard.TabIndex = 4;
            // 
            // tabHome
            // 
            this.tabHome.Controls.Add(this.grpHome);
            this.tabHome.Location = new System.Drawing.Point(4, 22);
            this.tabHome.Name = "tabHome";
            this.tabHome.Padding = new System.Windows.Forms.Padding(3);
            this.tabHome.Size = new System.Drawing.Size(848, 351);
            this.tabHome.TabIndex = 0;
            this.tabHome.Text = "Home";
            this.tabHome.UseVisualStyleBackColor = true;
            // 
            // grpHome
            // 
            this.grpHome.Controls.Add(this.lblAverageAcademicGirls);
            this.grpHome.Controls.Add(this.lblAverageAcademicBoys);
            this.grpHome.Controls.Add(this.lblAverageAcademic11);
            this.grpHome.Controls.Add(this.lblAverageAcademic10);
            this.grpHome.Controls.Add(this.lblAverageAcademic9);
            this.grpHome.Controls.Add(this.lblAverageAcademic8);
            this.grpHome.Controls.Add(this.lblAverageAcademic7);
            this.grpHome.Controls.Add(this.lblAverageEffortGirls);
            this.grpHome.Controls.Add(this.lblAverageEffortBoys);
            this.grpHome.Controls.Add(this.lblAverageEffort11);
            this.grpHome.Controls.Add(this.lblAverageEffort10);
            this.grpHome.Controls.Add(this.lblAverageEffort9);
            this.grpHome.Controls.Add(this.lblAverageEffort8);
            this.grpHome.Controls.Add(this.label54);
            this.grpHome.Controls.Add(this.label55);
            this.grpHome.Controls.Add(this.label52);
            this.grpHome.Controls.Add(this.label53);
            this.grpHome.Controls.Add(this.lblAverageEffort7);
            this.grpHome.Controls.Add(this.lblAverageAttendanceGirls);
            this.grpHome.Controls.Add(this.lblAverageAttendanceBoys);
            this.grpHome.Controls.Add(this.label47);
            this.grpHome.Controls.Add(this.label48);
            this.grpHome.Controls.Add(this.label49);
            this.grpHome.Controls.Add(this.label50);
            this.grpHome.Controls.Add(this.lblAverageAttendance11);
            this.grpHome.Controls.Add(this.lblAverageAttendance10);
            this.grpHome.Controls.Add(this.lblAverageAttendance9);
            this.grpHome.Controls.Add(this.lblAverageAttendance8);
            this.grpHome.Controls.Add(this.lblTotalGirls);
            this.grpHome.Controls.Add(this.lblTotalBoys);
            this.grpHome.Controls.Add(this.lblSumStudents);
            this.grpHome.Controls.Add(this.lblAverageAttendance7);
            this.grpHome.Controls.Add(this.lblAverageAcademic);
            this.grpHome.Controls.Add(this.lblAverageEffort);
            this.grpHome.Controls.Add(this.lblAverageAttendance);
            this.grpHome.Controls.Add(this.label26);
            this.grpHome.Controls.Add(this.label27);
            this.grpHome.Controls.Add(this.label28);
            this.grpHome.Controls.Add(this.label29);
            this.grpHome.Controls.Add(this.label30);
            this.grpHome.Controls.Add(this.label31);
            this.grpHome.Controls.Add(this.label20);
            this.grpHome.Controls.Add(this.label21);
            this.grpHome.Controls.Add(this.label22);
            this.grpHome.Controls.Add(this.label23);
            this.grpHome.Controls.Add(this.label24);
            this.grpHome.Controls.Add(this.label25);
            this.grpHome.Controls.Add(this.label19);
            this.grpHome.Controls.Add(this.label18);
            this.grpHome.Controls.Add(this.label17);
            this.grpHome.Controls.Add(this.label16);
            this.grpHome.Controls.Add(this.label15);
            this.grpHome.Controls.Add(this.label14);
            this.grpHome.Controls.Add(this.lblPercengirls);
            this.grpHome.Controls.Add(this.lblPercenboys);
            this.grpHome.Controls.Add(this.label3);
            this.grpHome.Location = new System.Drawing.Point(8, 6);
            this.grpHome.Name = "grpHome";
            this.grpHome.Size = new System.Drawing.Size(829, 327);
            this.grpHome.TabIndex = 28;
            this.grpHome.TabStop = false;
            // 
            // lblAverageAcademicGirls
            // 
            this.lblAverageAcademicGirls.AutoSize = true;
            this.lblAverageAcademicGirls.Location = new System.Drawing.Point(675, 265);
            this.lblAverageAcademicGirls.Name = "lblAverageAcademicGirls";
            this.lblAverageAcademicGirls.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademicGirls.TabIndex = 62;
            this.lblAverageAcademicGirls.Text = "0";
            // 
            // lblAverageAcademicBoys
            // 
            this.lblAverageAcademicBoys.AutoSize = true;
            this.lblAverageAcademicBoys.Location = new System.Drawing.Point(675, 240);
            this.lblAverageAcademicBoys.Name = "lblAverageAcademicBoys";
            this.lblAverageAcademicBoys.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademicBoys.TabIndex = 61;
            this.lblAverageAcademicBoys.Text = "0";
            // 
            // lblAverageAcademic11
            // 
            this.lblAverageAcademic11.AutoSize = true;
            this.lblAverageAcademic11.Location = new System.Drawing.Point(675, 216);
            this.lblAverageAcademic11.Name = "lblAverageAcademic11";
            this.lblAverageAcademic11.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademic11.TabIndex = 60;
            this.lblAverageAcademic11.Text = "0";
            // 
            // lblAverageAcademic10
            // 
            this.lblAverageAcademic10.AutoSize = true;
            this.lblAverageAcademic10.Location = new System.Drawing.Point(675, 193);
            this.lblAverageAcademic10.Name = "lblAverageAcademic10";
            this.lblAverageAcademic10.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademic10.TabIndex = 59;
            this.lblAverageAcademic10.Text = "0";
            // 
            // lblAverageAcademic9
            // 
            this.lblAverageAcademic9.AutoSize = true;
            this.lblAverageAcademic9.Location = new System.Drawing.Point(675, 170);
            this.lblAverageAcademic9.Name = "lblAverageAcademic9";
            this.lblAverageAcademic9.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademic9.TabIndex = 58;
            this.lblAverageAcademic9.Text = "0";
            // 
            // lblAverageAcademic8
            // 
            this.lblAverageAcademic8.AutoSize = true;
            this.lblAverageAcademic8.Location = new System.Drawing.Point(675, 149);
            this.lblAverageAcademic8.Name = "lblAverageAcademic8";
            this.lblAverageAcademic8.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademic8.TabIndex = 57;
            this.lblAverageAcademic8.Text = "0";
            // 
            // lblAverageAcademic7
            // 
            this.lblAverageAcademic7.AutoSize = true;
            this.lblAverageAcademic7.Location = new System.Drawing.Point(675, 125);
            this.lblAverageAcademic7.Name = "lblAverageAcademic7";
            this.lblAverageAcademic7.Size = new System.Drawing.Size(13, 13);
            this.lblAverageAcademic7.TabIndex = 56;
            this.lblAverageAcademic7.Text = "0";
            // 
            // lblAverageEffortGirls
            // 
            this.lblAverageEffortGirls.AutoSize = true;
            this.lblAverageEffortGirls.Location = new System.Drawing.Point(386, 267);
            this.lblAverageEffortGirls.Name = "lblAverageEffortGirls";
            this.lblAverageEffortGirls.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffortGirls.TabIndex = 55;
            this.lblAverageEffortGirls.Text = "0";
            // 
            // lblAverageEffortBoys
            // 
            this.lblAverageEffortBoys.AutoSize = true;
            this.lblAverageEffortBoys.Location = new System.Drawing.Point(386, 242);
            this.lblAverageEffortBoys.Name = "lblAverageEffortBoys";
            this.lblAverageEffortBoys.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffortBoys.TabIndex = 54;
            this.lblAverageEffortBoys.Text = "0";
            // 
            // lblAverageEffort11
            // 
            this.lblAverageEffort11.AutoSize = true;
            this.lblAverageEffort11.Location = new System.Drawing.Point(386, 218);
            this.lblAverageEffort11.Name = "lblAverageEffort11";
            this.lblAverageEffort11.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffort11.TabIndex = 53;
            this.lblAverageEffort11.Text = "0";
            // 
            // lblAverageEffort10
            // 
            this.lblAverageEffort10.AutoSize = true;
            this.lblAverageEffort10.Location = new System.Drawing.Point(386, 195);
            this.lblAverageEffort10.Name = "lblAverageEffort10";
            this.lblAverageEffort10.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffort10.TabIndex = 52;
            this.lblAverageEffort10.Text = "0";
            // 
            // lblAverageEffort9
            // 
            this.lblAverageEffort9.AutoSize = true;
            this.lblAverageEffort9.Location = new System.Drawing.Point(386, 172);
            this.lblAverageEffort9.Name = "lblAverageEffort9";
            this.lblAverageEffort9.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffort9.TabIndex = 51;
            this.lblAverageEffort9.Text = "0";
            // 
            // lblAverageEffort8
            // 
            this.lblAverageEffort8.AutoSize = true;
            this.lblAverageEffort8.Location = new System.Drawing.Point(386, 147);
            this.lblAverageEffort8.Name = "lblAverageEffort8";
            this.lblAverageEffort8.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffort8.TabIndex = 50;
            this.lblAverageEffort8.Text = "0";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(639, 267);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(30, 13);
            this.label54.TabIndex = 49;
            this.label54.Text = "Girls:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(636, 242);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(33, 13);
            this.label55.TabIndex = 48;
            this.label55.Text = "Boys:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(349, 267);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(30, 13);
            this.label52.TabIndex = 47;
            this.label52.Text = "Girls:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(346, 242);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(33, 13);
            this.label53.TabIndex = 46;
            this.label53.Text = "Boys:";
            // 
            // lblAverageEffort7
            // 
            this.lblAverageEffort7.AutoSize = true;
            this.lblAverageEffort7.Location = new System.Drawing.Point(386, 127);
            this.lblAverageEffort7.Name = "lblAverageEffort7";
            this.lblAverageEffort7.Size = new System.Drawing.Size(13, 13);
            this.lblAverageEffort7.TabIndex = 45;
            this.lblAverageEffort7.Text = "0";
            // 
            // lblAverageAttendanceGirls
            // 
            this.lblAverageAttendanceGirls.AutoSize = true;
            this.lblAverageAttendanceGirls.Location = new System.Drawing.Point(120, 267);
            this.lblAverageAttendanceGirls.Name = "lblAverageAttendanceGirls";
            this.lblAverageAttendanceGirls.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendanceGirls.TabIndex = 44;
            // 
            // lblAverageAttendanceBoys
            // 
            this.lblAverageAttendanceBoys.AutoSize = true;
            this.lblAverageAttendanceBoys.Location = new System.Drawing.Point(120, 242);
            this.lblAverageAttendanceBoys.Name = "lblAverageAttendanceBoys";
            this.lblAverageAttendanceBoys.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendanceBoys.TabIndex = 43;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(120, 267);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(0, 13);
            this.label47.TabIndex = 42;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(120, 242);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(0, 13);
            this.label48.TabIndex = 41;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(84, 267);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(30, 13);
            this.label49.TabIndex = 40;
            this.label49.Text = "Girls:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(81, 242);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(33, 13);
            this.label50.TabIndex = 39;
            this.label50.Text = "Boys:";
            // 
            // lblAverageAttendance11
            // 
            this.lblAverageAttendance11.AutoSize = true;
            this.lblAverageAttendance11.Location = new System.Drawing.Point(120, 218);
            this.lblAverageAttendance11.Name = "lblAverageAttendance11";
            this.lblAverageAttendance11.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendance11.TabIndex = 38;
            // 
            // lblAverageAttendance10
            // 
            this.lblAverageAttendance10.AutoSize = true;
            this.lblAverageAttendance10.Location = new System.Drawing.Point(120, 195);
            this.lblAverageAttendance10.Name = "lblAverageAttendance10";
            this.lblAverageAttendance10.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendance10.TabIndex = 37;
            // 
            // lblAverageAttendance9
            // 
            this.lblAverageAttendance9.AutoSize = true;
            this.lblAverageAttendance9.Location = new System.Drawing.Point(120, 173);
            this.lblAverageAttendance9.Name = "lblAverageAttendance9";
            this.lblAverageAttendance9.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendance9.TabIndex = 36;
            // 
            // lblAverageAttendance8
            // 
            this.lblAverageAttendance8.AutoSize = true;
            this.lblAverageAttendance8.Location = new System.Drawing.Point(120, 149);
            this.lblAverageAttendance8.Name = "lblAverageAttendance8";
            this.lblAverageAttendance8.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendance8.TabIndex = 35;
            // 
            // lblTotalGirls
            // 
            this.lblTotalGirls.AutoSize = true;
            this.lblTotalGirls.Location = new System.Drawing.Point(120, 67);
            this.lblTotalGirls.Name = "lblTotalGirls";
            this.lblTotalGirls.Size = new System.Drawing.Size(0, 13);
            this.lblTotalGirls.TabIndex = 34;
            // 
            // lblTotalBoys
            // 
            this.lblTotalBoys.AutoSize = true;
            this.lblTotalBoys.Location = new System.Drawing.Point(120, 42);
            this.lblTotalBoys.Name = "lblTotalBoys";
            this.lblTotalBoys.Size = new System.Drawing.Size(0, 13);
            this.lblTotalBoys.TabIndex = 33;
            // 
            // lblSumStudents
            // 
            this.lblSumStudents.AutoSize = true;
            this.lblSumStudents.Location = new System.Drawing.Point(120, 14);
            this.lblSumStudents.Name = "lblSumStudents";
            this.lblSumStudents.Size = new System.Drawing.Size(0, 13);
            this.lblSumStudents.TabIndex = 32;
            // 
            // lblAverageAttendance7
            // 
            this.lblAverageAttendance7.AutoSize = true;
            this.lblAverageAttendance7.Location = new System.Drawing.Point(120, 125);
            this.lblAverageAttendance7.Name = "lblAverageAttendance7";
            this.lblAverageAttendance7.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendance7.TabIndex = 31;
            // 
            // lblAverageAcademic
            // 
            this.lblAverageAcademic.AutoSize = true;
            this.lblAverageAcademic.Location = new System.Drawing.Point(675, 101);
            this.lblAverageAcademic.Name = "lblAverageAcademic";
            this.lblAverageAcademic.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAcademic.TabIndex = 30;
            // 
            // lblAverageEffort
            // 
            this.lblAverageEffort.AutoSize = true;
            this.lblAverageEffort.Location = new System.Drawing.Point(386, 101);
            this.lblAverageEffort.Name = "lblAverageEffort";
            this.lblAverageEffort.Size = new System.Drawing.Size(0, 13);
            this.lblAverageEffort.TabIndex = 29;
            // 
            // lblAverageAttendance
            // 
            this.lblAverageAttendance.AutoSize = true;
            this.lblAverageAttendance.Location = new System.Drawing.Point(120, 99);
            this.lblAverageAttendance.Name = "lblAverageAttendance";
            this.lblAverageAttendance.Size = new System.Drawing.Size(0, 13);
            this.lblAverageAttendance.TabIndex = 28;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(622, 218);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(47, 13);
            this.label26.TabIndex = 27;
            this.label26.Text = "Year 11:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(622, 195);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 13);
            this.label27.TabIndex = 26;
            this.label27.Text = "Year 10:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(628, 172);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 13);
            this.label28.TabIndex = 25;
            this.label28.Text = "Year 9:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(628, 149);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 13);
            this.label29.TabIndex = 24;
            this.label29.Text = "Year 8:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(628, 127);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 13);
            this.label30.TabIndex = 23;
            this.label30.Text = "Year 7:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(569, 101);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(100, 13);
            this.label31.TabIndex = 22;
            this.label31.Text = "Average Academic:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(333, 218);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 13);
            this.label20.TabIndex = 21;
            this.label20.Text = "Year 11:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(333, 195);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 13);
            this.label21.TabIndex = 20;
            this.label21.Text = "Year 10:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(339, 172);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 13);
            this.label22.TabIndex = 19;
            this.label22.Text = "Year 9:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(339, 149);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 18;
            this.label23.Text = "Year 8:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(339, 127);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 13);
            this.label24.TabIndex = 17;
            this.label24.Text = "Year 7:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(302, 101);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 13);
            this.label25.TabIndex = 16;
            this.label25.Text = "Average Effort:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(67, 216);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 13);
            this.label19.TabIndex = 15;
            this.label19.Text = "Year 11:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(67, 193);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 13);
            this.label18.TabIndex = 14;
            this.label18.Text = "Year 10:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(73, 170);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "Year 9:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(73, 147);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "Year 8:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(73, 125);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "Year 7:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 99);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "Average Attendance:";
            // 
            // lblPercengirls
            // 
            this.lblPercengirls.AutoSize = true;
            this.lblPercengirls.Location = new System.Drawing.Point(84, 67);
            this.lblPercengirls.Name = "lblPercengirls";
            this.lblPercengirls.Size = new System.Drawing.Size(30, 13);
            this.lblPercengirls.TabIndex = 4;
            this.lblPercengirls.Text = "Girls:";
            // 
            // lblPercenboys
            // 
            this.lblPercenboys.AutoSize = true;
            this.lblPercenboys.Location = new System.Drawing.Point(81, 42);
            this.lblPercenboys.Name = "lblPercenboys";
            this.lblPercenboys.Size = new System.Drawing.Size(33, 13);
            this.lblPercenboys.TabIndex = 3;
            this.lblPercenboys.Text = "Boys:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Total Students:";
            // 
            // tabStudents
            // 
            this.tabStudents.Controls.Add(this.lblWrongUpn);
            this.tabStudents.Controls.Add(this.grpStudent);
            this.tabStudents.Controls.Add(this.btnSearch);
            this.tabStudents.Controls.Add(this.txtSearch);
            this.tabStudents.Controls.Add(this.label13);
            this.tabStudents.Controls.Add(this.shapeContainer2);
            this.tabStudents.Location = new System.Drawing.Point(4, 22);
            this.tabStudents.Name = "tabStudents";
            this.tabStudents.Padding = new System.Windows.Forms.Padding(3);
            this.tabStudents.Size = new System.Drawing.Size(848, 351);
            this.tabStudents.TabIndex = 1;
            this.tabStudents.Text = "Students";
            this.tabStudents.UseVisualStyleBackColor = true;
            // 
            // lblWrongUpn
            // 
            this.lblWrongUpn.AutoSize = true;
            this.lblWrongUpn.ForeColor = System.Drawing.Color.Red;
            this.lblWrongUpn.Location = new System.Drawing.Point(356, 9);
            this.lblWrongUpn.Name = "lblWrongUpn";
            this.lblWrongUpn.Size = new System.Drawing.Size(0, 13);
            this.lblWrongUpn.TabIndex = 16;
            // 
            // grpStudent
            // 
            this.grpStudent.Controls.Add(this.lblAttendanceValue);
            this.grpStudent.Controls.Add(this.lblEffortValue);
            this.grpStudent.Controls.Add(this.label45);
            this.grpStudent.Controls.Add(this.lblAcademicValue);
            this.grpStudent.Controls.Add(this.label46);
            this.grpStudent.Controls.Add(this.label12);
            this.grpStudent.Controls.Add(this.lblPostCodeValue);
            this.grpStudent.Controls.Add(this.lblYearValue);
            this.grpStudent.Controls.Add(this.lblHouseValue);
            this.grpStudent.Controls.Add(this.lblRegistrationValue);
            this.grpStudent.Controls.Add(this.lblUpnNumberValue);
            this.grpStudent.Controls.Add(this.lblAdNumberValue);
            this.grpStudent.Controls.Add(this.lblFreeMealValue);
            this.grpStudent.Controls.Add(this.lblSenValue);
            this.grpStudent.Controls.Add(this.lblLeaValue);
            this.grpStudent.Controls.Add(this.lblQuickNoteValue);
            this.grpStudent.Controls.Add(this.lblLanguageValue);
            this.grpStudent.Controls.Add(this.lblEthnicityValue);
            this.grpStudent.Controls.Add(this.lblGenderValue);
            this.grpStudent.Controls.Add(this.lblSurnameValue);
            this.grpStudent.Controls.Add(this.lblForenameValue);
            this.grpStudent.Controls.Add(this.label37);
            this.grpStudent.Controls.Add(this.label36);
            this.grpStudent.Controls.Add(this.label35);
            this.grpStudent.Controls.Add(this.label34);
            this.grpStudent.Controls.Add(this.label33);
            this.grpStudent.Controls.Add(this.label2);
            this.grpStudent.Controls.Add(this.label32);
            this.grpStudent.Controls.Add(this.label10);
            this.grpStudent.Controls.Add(this.label11);
            this.grpStudent.Controls.Add(this.label9);
            this.grpStudent.Controls.Add(this.label8);
            this.grpStudent.Controls.Add(this.label7);
            this.grpStudent.Controls.Add(this.label4);
            this.grpStudent.Controls.Add(this.label6);
            this.grpStudent.Controls.Add(this.label5);
            this.grpStudent.Location = new System.Drawing.Point(18, 44);
            this.grpStudent.Name = "grpStudent";
            this.grpStudent.Size = new System.Drawing.Size(806, 275);
            this.grpStudent.TabIndex = 15;
            this.grpStudent.TabStop = false;
            this.grpStudent.Visible = false;
            // 
            // lblAttendanceValue
            // 
            this.lblAttendanceValue.AutoSize = true;
            this.lblAttendanceValue.Location = new System.Drawing.Point(642, 126);
            this.lblAttendanceValue.Name = "lblAttendanceValue";
            this.lblAttendanceValue.Size = new System.Drawing.Size(0, 13);
            this.lblAttendanceValue.TabIndex = 42;
            // 
            // lblEffortValue
            // 
            this.lblEffortValue.AutoSize = true;
            this.lblEffortValue.Location = new System.Drawing.Point(642, 149);
            this.lblEffortValue.Name = "lblEffortValue";
            this.lblEffortValue.Size = new System.Drawing.Size(0, 13);
            this.lblEffortValue.TabIndex = 41;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(601, 149);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 13);
            this.label45.TabIndex = 40;
            this.label45.Text = "Effort:";
            // 
            // lblAcademicValue
            // 
            this.lblAcademicValue.AutoSize = true;
            this.lblAcademicValue.Location = new System.Drawing.Point(642, 171);
            this.lblAcademicValue.Name = "lblAcademicValue";
            this.lblAcademicValue.Size = new System.Drawing.Size(0, 13);
            this.lblAcademicValue.TabIndex = 39;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(582, 171);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(60, 13);
            this.label46.TabIndex = 37;
            this.label46.Text = "Academic: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(551, 126);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 35;
            this.label12.Text = "Attendance (%): ";
            // 
            // lblPostCodeValue
            // 
            this.lblPostCodeValue.AutoSize = true;
            this.lblPostCodeValue.Location = new System.Drawing.Point(360, 149);
            this.lblPostCodeValue.Name = "lblPostCodeValue";
            this.lblPostCodeValue.Size = new System.Drawing.Size(0, 13);
            this.lblPostCodeValue.TabIndex = 34;
            // 
            // lblYearValue
            // 
            this.lblYearValue.AutoSize = true;
            this.lblYearValue.Location = new System.Drawing.Point(360, 126);
            this.lblYearValue.Name = "lblYearValue";
            this.lblYearValue.Size = new System.Drawing.Size(0, 13);
            this.lblYearValue.TabIndex = 33;
            // 
            // lblHouseValue
            // 
            this.lblHouseValue.AutoSize = true;
            this.lblHouseValue.Location = new System.Drawing.Point(361, 103);
            this.lblHouseValue.Name = "lblHouseValue";
            this.lblHouseValue.Size = new System.Drawing.Size(0, 13);
            this.lblHouseValue.TabIndex = 32;
            // 
            // lblRegistrationValue
            // 
            this.lblRegistrationValue.AutoSize = true;
            this.lblRegistrationValue.Location = new System.Drawing.Point(361, 79);
            this.lblRegistrationValue.Name = "lblRegistrationValue";
            this.lblRegistrationValue.Size = new System.Drawing.Size(0, 13);
            this.lblRegistrationValue.TabIndex = 31;
            // 
            // lblUpnNumberValue
            // 
            this.lblUpnNumberValue.AutoSize = true;
            this.lblUpnNumberValue.Location = new System.Drawing.Point(361, 56);
            this.lblUpnNumberValue.Name = "lblUpnNumberValue";
            this.lblUpnNumberValue.Size = new System.Drawing.Size(0, 13);
            this.lblUpnNumberValue.TabIndex = 30;
            // 
            // lblAdNumberValue
            // 
            this.lblAdNumberValue.AutoSize = true;
            this.lblAdNumberValue.Location = new System.Drawing.Point(361, 33);
            this.lblAdNumberValue.Name = "lblAdNumberValue";
            this.lblAdNumberValue.Size = new System.Drawing.Size(0, 13);
            this.lblAdNumberValue.TabIndex = 29;
            // 
            // lblFreeMealValue
            // 
            this.lblFreeMealValue.AutoSize = true;
            this.lblFreeMealValue.Location = new System.Drawing.Point(642, 79);
            this.lblFreeMealValue.Name = "lblFreeMealValue";
            this.lblFreeMealValue.Size = new System.Drawing.Size(0, 13);
            this.lblFreeMealValue.TabIndex = 28;
            // 
            // lblSenValue
            // 
            this.lblSenValue.AutoSize = true;
            this.lblSenValue.Location = new System.Drawing.Point(642, 56);
            this.lblSenValue.Name = "lblSenValue";
            this.lblSenValue.Size = new System.Drawing.Size(0, 13);
            this.lblSenValue.TabIndex = 27;
            // 
            // lblLeaValue
            // 
            this.lblLeaValue.AutoSize = true;
            this.lblLeaValue.Location = new System.Drawing.Point(642, 33);
            this.lblLeaValue.Name = "lblLeaValue";
            this.lblLeaValue.Size = new System.Drawing.Size(0, 13);
            this.lblLeaValue.TabIndex = 26;
            // 
            // lblQuickNoteValue
            // 
            this.lblQuickNoteValue.AutoSize = true;
            this.lblQuickNoteValue.Location = new System.Drawing.Point(94, 221);
            this.lblQuickNoteValue.Name = "lblQuickNoteValue";
            this.lblQuickNoteValue.Size = new System.Drawing.Size(0, 13);
            this.lblQuickNoteValue.TabIndex = 25;
            // 
            // lblLanguageValue
            // 
            this.lblLanguageValue.AutoSize = true;
            this.lblLanguageValue.Location = new System.Drawing.Point(92, 125);
            this.lblLanguageValue.Name = "lblLanguageValue";
            this.lblLanguageValue.Size = new System.Drawing.Size(0, 13);
            this.lblLanguageValue.TabIndex = 24;
            // 
            // lblEthnicityValue
            // 
            this.lblEthnicityValue.AutoSize = true;
            this.lblEthnicityValue.Location = new System.Drawing.Point(92, 102);
            this.lblEthnicityValue.Name = "lblEthnicityValue";
            this.lblEthnicityValue.Size = new System.Drawing.Size(0, 13);
            this.lblEthnicityValue.TabIndex = 23;
            // 
            // lblGenderValue
            // 
            this.lblGenderValue.AutoSize = true;
            this.lblGenderValue.Location = new System.Drawing.Point(92, 79);
            this.lblGenderValue.Name = "lblGenderValue";
            this.lblGenderValue.Size = new System.Drawing.Size(0, 13);
            this.lblGenderValue.TabIndex = 22;
            // 
            // lblSurnameValue
            // 
            this.lblSurnameValue.AutoSize = true;
            this.lblSurnameValue.Location = new System.Drawing.Point(92, 55);
            this.lblSurnameValue.Name = "lblSurnameValue";
            this.lblSurnameValue.Size = new System.Drawing.Size(0, 13);
            this.lblSurnameValue.TabIndex = 20;
            // 
            // lblForenameValue
            // 
            this.lblForenameValue.AutoSize = true;
            this.lblForenameValue.Location = new System.Drawing.Point(92, 33);
            this.lblForenameValue.Name = "lblForenameValue";
            this.lblForenameValue.Size = new System.Drawing.Size(0, 13);
            this.lblForenameValue.TabIndex = 19;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(22, 221);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(64, 13);
            this.label37.TabIndex = 18;
            this.label37.Text = "Quick Note:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(294, 149);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(59, 13);
            this.label36.TabIndex = 9;
            this.label36.Text = "Post Code:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(6, 125);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(80, 13);
            this.label35.TabIndex = 17;
            this.label35.Text = "First Language:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(290, 79);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 13);
            this.label34.TabIndex = 16;
            this.label34.Text = "Registration:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(290, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 13);
            this.label33.TabIndex = 15;
            this.label33.Text = "AD Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Forename:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(34, 56);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 13);
            this.label32.TabIndex = 14;
            this.label32.Text = "Surname:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(34, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "Ethnicity:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(41, 79);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Gender:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(282, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "UPN Number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(581, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "LEA Care:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(574, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Free Meals:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(321, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Year:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(571, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "SEN Status:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(312, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "House:";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(262, 4);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 13;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(89, 6);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(167, 20);
            this.txtSearch.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "Search (UPN):";
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer2.Size = new System.Drawing.Size(842, 345);
            this.shapeContainer2.TabIndex = 12;
            this.shapeContainer2.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 17;
            this.lineShape1.X2 = 820;
            this.lineShape1.Y1 = 31;
            this.lineShape1.Y2 = 31;
            // 
            // tabCharts
            // 
            this.tabCharts.Controls.Add(this.groupBox1);
            this.tabCharts.Controls.Add(this.grpSort);
            this.tabCharts.Controls.Add(this.lblTotalStudents);
            this.tabCharts.Controls.Add(this.lblEffortAcademicSilver);
            this.tabCharts.Controls.Add(this.lblAttendanceAcademicSilver);
            this.tabCharts.Controls.Add(this.cboAttendance);
            this.tabCharts.Controls.Add(this.lblEffort);
            this.tabCharts.Controls.Add(this.cboAcademic);
            this.tabCharts.Controls.Add(this.label38);
            this.tabCharts.Controls.Add(this.cboEffort);
            this.tabCharts.Controls.Add(this.lblGold);
            this.tabCharts.Controls.Add(this.lblAttendanceEffortSilver);
            this.tabCharts.Controls.Add(this.label42);
            this.tabCharts.Controls.Add(this.label39);
            this.tabCharts.Controls.Add(this.label44);
            this.tabCharts.Controls.Add(this.label43);
            this.tabCharts.Controls.Add(this.lblAcademic);
            this.tabCharts.Controls.Add(this.lblAttendance);
            this.tabCharts.Controls.Add(this.label40);
            this.tabCharts.Controls.Add(this.label41);
            this.tabCharts.Controls.Add(this.picVennDiagram);
            this.tabCharts.Location = new System.Drawing.Point(4, 22);
            this.tabCharts.Name = "tabCharts";
            this.tabCharts.Padding = new System.Windows.Forms.Padding(3);
            this.tabCharts.Size = new System.Drawing.Size(848, 351);
            this.tabCharts.TabIndex = 2;
            this.tabCharts.Text = "Charts";
            this.tabCharts.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.listView1);
            this.groupBox1.Controls.Add(this.btnDisplay);
            this.groupBox1.Controls.Add(this.label56);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.cboFilter);
            this.groupBox1.Location = new System.Drawing.Point(460, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(364, 210);
            this.groupBox1.TabIndex = 53;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filter";
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(284, 22);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(77, 25);
            this.btnDisplay.TabIndex = 4;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(18, 65);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(43, 13);
            this.label56.TabIndex = 2;
            this.label56.Text = "Names:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(18, 22);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(72, 13);
            this.label51.TabIndex = 0;
            this.label51.Text = "Achievement:";
            // 
            // cboFilter
            // 
            this.cboFilter.FormattingEnabled = true;
            this.cboFilter.Location = new System.Drawing.Point(96, 19);
            this.cboFilter.Name = "cboFilter";
            this.cboFilter.Size = new System.Drawing.Size(82, 21);
            this.cboFilter.TabIndex = 1;
            // 
            // grpSort
            // 
            this.grpSort.Controls.Add(this.chkHouseEnable);
            this.grpSort.Controls.Add(this.chkGenderEnable);
            this.grpSort.Controls.Add(this.chkYearEnable);
            this.grpSort.Controls.Add(this.btnAddSorts);
            this.grpSort.Controls.Add(this.cboHouse);
            this.grpSort.Controls.Add(this.cboYear);
            this.grpSort.Controls.Add(this.cboGender);
            this.grpSort.Controls.Add(this.btnPrint);
            this.grpSort.Location = new System.Drawing.Point(460, 6);
            this.grpSort.Name = "grpSort";
            this.grpSort.Size = new System.Drawing.Size(365, 100);
            this.grpSort.TabIndex = 52;
            this.grpSort.TabStop = false;
            this.grpSort.Text = "Sort by";
            // 
            // chkHouseEnable
            // 
            this.chkHouseEnable.AutoSize = true;
            this.chkHouseEnable.Location = new System.Drawing.Point(133, 74);
            this.chkHouseEnable.Name = "chkHouseEnable";
            this.chkHouseEnable.Size = new System.Drawing.Size(59, 17);
            this.chkHouseEnable.TabIndex = 58;
            this.chkHouseEnable.Text = "Enable";
            this.chkHouseEnable.UseVisualStyleBackColor = true;
            this.chkHouseEnable.CheckedChanged += new System.EventHandler(this.chkHouseEnable_CheckedChanged);
            // 
            // chkGenderEnable
            // 
            this.chkGenderEnable.AutoSize = true;
            this.chkGenderEnable.Location = new System.Drawing.Point(133, 48);
            this.chkGenderEnable.Name = "chkGenderEnable";
            this.chkGenderEnable.Size = new System.Drawing.Size(59, 17);
            this.chkGenderEnable.TabIndex = 57;
            this.chkGenderEnable.Text = "Enable";
            this.chkGenderEnable.UseVisualStyleBackColor = true;
            this.chkGenderEnable.CheckedChanged += new System.EventHandler(this.chkGenderEnable_CheckedChanged);
            // 
            // chkYearEnable
            // 
            this.chkYearEnable.AutoSize = true;
            this.chkYearEnable.Location = new System.Drawing.Point(133, 21);
            this.chkYearEnable.Name = "chkYearEnable";
            this.chkYearEnable.Size = new System.Drawing.Size(59, 17);
            this.chkYearEnable.TabIndex = 56;
            this.chkYearEnable.Text = "Enable";
            this.chkYearEnable.UseVisualStyleBackColor = true;
            this.chkYearEnable.CheckedChanged += new System.EventHandler(this.chkYearEnable_CheckedChanged);
            // 
            // btnAddSorts
            // 
            this.btnAddSorts.Location = new System.Drawing.Point(284, 17);
            this.btnAddSorts.Name = "btnAddSorts";
            this.btnAddSorts.Size = new System.Drawing.Size(75, 23);
            this.btnAddSorts.TabIndex = 55;
            this.btnAddSorts.Text = "Load Chart";
            this.btnAddSorts.UseVisualStyleBackColor = true;
            this.btnAddSorts.Click += new System.EventHandler(this.btnAddSorts_Click);
            // 
            // cboHouse
            // 
            this.cboHouse.Enabled = false;
            this.cboHouse.FormattingEnabled = true;
            this.cboHouse.Location = new System.Drawing.Point(6, 72);
            this.cboHouse.Name = "cboHouse";
            this.cboHouse.Size = new System.Drawing.Size(121, 21);
            this.cboHouse.TabIndex = 54;
            this.cboHouse.Text = "House";
            // 
            // cboYear
            // 
            this.cboYear.Enabled = false;
            this.cboYear.FormattingEnabled = true;
            this.cboYear.Location = new System.Drawing.Point(6, 19);
            this.cboYear.Name = "cboYear";
            this.cboYear.Size = new System.Drawing.Size(121, 21);
            this.cboYear.TabIndex = 53;
            this.cboYear.Text = "Year";
            // 
            // cboGender
            // 
            this.cboGender.Enabled = false;
            this.cboGender.FormattingEnabled = true;
            this.cboGender.Location = new System.Drawing.Point(6, 46);
            this.cboGender.Name = "cboGender";
            this.cboGender.Size = new System.Drawing.Size(121, 21);
            this.cboGender.TabIndex = 51;
            this.cboGender.Text = "Gender";
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(284, 70);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 32;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // lblTotalStudents
            // 
            this.lblTotalStudents.AutoSize = true;
            this.lblTotalStudents.Location = new System.Drawing.Point(414, 11);
            this.lblTotalStudents.Name = "lblTotalStudents";
            this.lblTotalStudents.Size = new System.Drawing.Size(13, 13);
            this.lblTotalStudents.TabIndex = 50;
            this.lblTotalStudents.Text = "0";
            // 
            // lblEffortAcademicSilver
            // 
            this.lblEffortAcademicSilver.AutoSize = true;
            this.lblEffortAcademicSilver.Location = new System.Drawing.Point(278, 177);
            this.lblEffortAcademicSilver.Name = "lblEffortAcademicSilver";
            this.lblEffortAcademicSilver.Size = new System.Drawing.Size(13, 13);
            this.lblEffortAcademicSilver.TabIndex = 49;
            this.lblEffortAcademicSilver.Text = "0";
            // 
            // lblAttendanceAcademicSilver
            // 
            this.lblAttendanceAcademicSilver.AutoSize = true;
            this.lblAttendanceAcademicSilver.Location = new System.Drawing.Point(147, 177);
            this.lblAttendanceAcademicSilver.Name = "lblAttendanceAcademicSilver";
            this.lblAttendanceAcademicSilver.Size = new System.Drawing.Size(13, 13);
            this.lblAttendanceAcademicSilver.TabIndex = 48;
            this.lblAttendanceAcademicSilver.Text = "0";
            // 
            // cboAttendance
            // 
            this.cboAttendance.FormattingEnabled = true;
            this.cboAttendance.Location = new System.Drawing.Point(118, 69);
            this.cboAttendance.Name = "cboAttendance";
            this.cboAttendance.Size = new System.Drawing.Size(42, 21);
            this.cboAttendance.TabIndex = 36;
            this.cboAttendance.Text = "50";
            // 
            // lblEffort
            // 
            this.lblEffort.AutoSize = true;
            this.lblEffort.Location = new System.Drawing.Point(308, 96);
            this.lblEffort.Name = "lblEffort";
            this.lblEffort.Size = new System.Drawing.Size(13, 13);
            this.lblEffort.TabIndex = 43;
            this.lblEffort.Text = "0";
            // 
            // cboAcademic
            // 
            this.cboAcademic.FormattingEnabled = true;
            this.cboAcademic.Location = new System.Drawing.Point(215, 253);
            this.cboAcademic.Name = "cboAcademic";
            this.cboAcademic.Size = new System.Drawing.Size(32, 21);
            this.cboAcademic.TabIndex = 41;
            this.cboAcademic.Text = "1";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(196, 256);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(13, 13);
            this.label38.TabIndex = 39;
            this.label38.Text = ">";
            // 
            // cboEffort
            // 
            this.cboEffort.FormattingEnabled = true;
            this.cboEffort.Location = new System.Drawing.Point(308, 69);
            this.cboEffort.Name = "cboEffort";
            this.cboEffort.Size = new System.Drawing.Size(32, 21);
            this.cboEffort.TabIndex = 40;
            this.cboEffort.Text = "1";
            // 
            // lblGold
            // 
            this.lblGold.AutoSize = true;
            this.lblGold.Location = new System.Drawing.Point(216, 142);
            this.lblGold.Name = "lblGold";
            this.lblGold.Size = new System.Drawing.Size(13, 13);
            this.lblGold.TabIndex = 46;
            this.lblGold.Text = "0";
            // 
            // lblAttendanceEffortSilver
            // 
            this.lblAttendanceEffortSilver.AutoSize = true;
            this.lblAttendanceEffortSilver.Location = new System.Drawing.Point(215, 79);
            this.lblAttendanceEffortSilver.Name = "lblAttendanceEffortSilver";
            this.lblAttendanceEffortSilver.Size = new System.Drawing.Size(13, 13);
            this.lblAttendanceEffortSilver.TabIndex = 47;
            this.lblAttendanceEffortSilver.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.White;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(291, 46);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(49, 20);
            this.label42.TabIndex = 34;
            this.label42.Text = "Effort";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(292, 72);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(13, 13);
            this.label39.TabIndex = 38;
            this.label39.Text = ">";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(340, 10);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(79, 13);
            this.label44.TabIndex = 31;
            this.label44.Text = "Total Students:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.White;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(83, 46);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(92, 20);
            this.label43.TabIndex = 33;
            this.label43.Text = "Attendance";
            // 
            // lblAcademic
            // 
            this.lblAcademic.AutoSize = true;
            this.lblAcademic.Location = new System.Drawing.Point(213, 282);
            this.lblAcademic.Name = "lblAcademic";
            this.lblAcademic.Size = new System.Drawing.Size(13, 13);
            this.lblAcademic.TabIndex = 44;
            this.lblAcademic.Text = "0";
            // 
            // lblAttendance
            // 
            this.lblAttendance.AutoSize = true;
            this.lblAttendance.Location = new System.Drawing.Point(113, 100);
            this.lblAttendance.Name = "lblAttendance";
            this.lblAttendance.Size = new System.Drawing.Size(13, 13);
            this.lblAttendance.TabIndex = 42;
            this.lblAttendance.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(99, 72);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(13, 13);
            this.label40.TabIndex = 37;
            this.label40.Text = ">";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.White;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(184, 230);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(79, 20);
            this.label41.TabIndex = 35;
            this.label41.Text = "Academic";
            // 
            // picVennDiagram
            // 
            this.picVennDiagram.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picVennDiagram.Image = global::Project.Properties.Resources.VennDiagram;
            this.picVennDiagram.InitialImage = global::Project.Properties.Resources.VennDiagram;
            this.picVennDiagram.Location = new System.Drawing.Point(8, 6);
            this.picVennDiagram.Name = "picVennDiagram";
            this.picVennDiagram.Size = new System.Drawing.Size(433, 328);
            this.picVennDiagram.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVennDiagram.TabIndex = 30;
            this.picVennDiagram.TabStop = false;
            // 
            // lblHome
            // 
            this.lblHome.AutoSize = true;
            this.lblHome.BackColor = System.Drawing.SystemColors.Control;
            this.lblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHome.LinkColor = System.Drawing.Color.Black;
            this.lblHome.Location = new System.Drawing.Point(173, 106);
            this.lblHome.Name = "lblHome";
            this.lblHome.Size = new System.Drawing.Size(68, 25);
            this.lblHome.TabIndex = 5;
            this.lblHome.TabStop = true;
            this.lblHome.Text = "Home";
            this.lblHome.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblHome_LinkClicked);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Title = "Select File";
            // 
            // lblCharts
            // 
            this.lblCharts.AutoSize = true;
            this.lblCharts.BackColor = System.Drawing.SystemColors.Control;
            this.lblCharts.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCharts.LinkColor = System.Drawing.Color.Black;
            this.lblCharts.Location = new System.Drawing.Point(417, 106);
            this.lblCharts.Name = "lblCharts";
            this.lblCharts.Size = new System.Drawing.Size(75, 25);
            this.lblCharts.TabIndex = 7;
            this.lblCharts.TabStop = true;
            this.lblCharts.Text = "Charts";
            this.lblCharts.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblCharts_LinkClicked);
            // 
            // picLogo
            // 
            this.picLogo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.Location = new System.Drawing.Point(3, 3);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(127, 125);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 1;
            this.picLogo.TabStop = false;
            // 
            // lblStudents
            // 
            this.lblStudents.AutoSize = true;
            this.lblStudents.BackColor = System.Drawing.SystemColors.Control;
            this.lblStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudents.LinkColor = System.Drawing.Color.Black;
            this.lblStudents.Location = new System.Drawing.Point(280, 106);
            this.lblStudents.Name = "lblStudents";
            this.lblStudents.Size = new System.Drawing.Size(97, 25);
            this.lblStudents.TabIndex = 8;
            this.lblStudents.TabStop = true;
            this.lblStudents.Text = "Students";
            this.lblStudents.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblStudents_LinkClicked_1);
            // 
            // lblLoadStatus
            // 
            this.lblLoadStatus.AutoSize = true;
            this.lblLoadStatus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblLoadStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadStatus.Location = new System.Drawing.Point(598, 91);
            this.lblLoadStatus.Name = "lblLoadStatus";
            this.lblLoadStatus.Size = new System.Drawing.Size(252, 37);
            this.lblLoadStatus.TabIndex = 9;
            this.lblLoadStatus.Text = "No Data Loaded";
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(67, 65);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(211, 139);
            this.listView1.TabIndex = 5;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(284, 65);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(74, 28);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 501);
            this.Controls.Add(this.lblLoadStatus);
            this.Controls.Add(this.lblStudents);
            this.Controls.Add(this.lblCharts);
            this.Controls.Add(this.lblHome);
            this.Controls.Add(this.tabDashboard);
            this.Controls.Add(this.btnImport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.shapeContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dene Community School";
            this.Load += new System.EventHandler(this.frmDashboard_Load);
            this.tabDashboard.ResumeLayout(false);
            this.tabHome.ResumeLayout(false);
            this.grpHome.ResumeLayout(false);
            this.grpHome.PerformLayout();
            this.tabStudents.ResumeLayout(false);
            this.tabStudents.PerformLayout();
            this.grpStudent.ResumeLayout(false);
            this.grpStudent.PerformLayout();
            this.tabCharts.ResumeLayout(false);
            this.tabCharts.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpSort.ResumeLayout(false);
            this.grpSort.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picVennDiagram)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape Topbar;
        private System.Windows.Forms.PictureBox picLogo;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape recSingle;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape recHome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.TabControl tabDashboard;
        private System.Windows.Forms.TabPage tabHome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabStudents;
        private System.Windows.Forms.LinkLabel lblHome;
        private System.Windows.Forms.Label lblPercengirls;
        private System.Windows.Forms.Label lblPercenboys;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape reCharts;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private System.Windows.Forms.LinkLabel lblCharts;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox grpStudent;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.LinkLabel lblStudents;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TabPage tabCharts;
        private System.Windows.Forms.ComboBox cboAttendance;
        private System.Windows.Forms.Label lblEffort;
        private System.Windows.Forms.ComboBox cboAcademic;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox cboEffort;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label lblGold;
        private System.Windows.Forms.Label lblAttendanceEffortSilver;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lblAcademic;
        private System.Windows.Forms.Label lblAttendance;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.PictureBox picVennDiagram;
        private System.Windows.Forms.Label lblWrongUpn;
        private System.Windows.Forms.Label lblForenameValue;
        private System.Windows.Forms.Label lblPostCodeValue;
        private System.Windows.Forms.Label lblYearValue;
        private System.Windows.Forms.Label lblHouseValue;
        private System.Windows.Forms.Label lblRegistrationValue;
        private System.Windows.Forms.Label lblUpnNumberValue;
        private System.Windows.Forms.Label lblAdNumberValue;
        private System.Windows.Forms.Label lblFreeMealValue;
        private System.Windows.Forms.Label lblSenValue;
        private System.Windows.Forms.Label lblLeaValue;
        private System.Windows.Forms.Label lblQuickNoteValue;
        private System.Windows.Forms.Label lblLanguageValue;
        private System.Windows.Forms.Label lblEthnicityValue;
        private System.Windows.Forms.Label lblGenderValue;
        private System.Windows.Forms.Label lblSurnameValue;
        private System.Windows.Forms.Label lblLoadStatus;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblAcademicValue;
        private System.Windows.Forms.Label lblEffortValue;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lblAttendanceValue;
        private System.Windows.Forms.GroupBox grpHome;
        private System.Windows.Forms.Label lblAverageAttendance;
        private System.Windows.Forms.Label lblAverageAcademic;
        private System.Windows.Forms.Label lblAverageEffort;
        private System.Windows.Forms.Label lblAverageAttendance7;
        private System.Windows.Forms.Label lblEffortAcademicSilver;
        private System.Windows.Forms.Label lblAttendanceAcademicSilver;
        private System.Windows.Forms.Label lblTotalStudents;
        private System.Windows.Forms.ComboBox cboGender;
        private System.Windows.Forms.GroupBox grpSort;
        private System.Windows.Forms.ComboBox cboYear;
        private System.Windows.Forms.ComboBox cboHouse;
        private System.Windows.Forms.Label lblSumStudents;
        private System.Windows.Forms.Label lblTotalGirls;
        private System.Windows.Forms.Label lblTotalBoys;
        private System.Windows.Forms.Label lblAverageAttendance11;
        private System.Windows.Forms.Label lblAverageAttendance10;
        private System.Windows.Forms.Label lblAverageAttendance9;
        private System.Windows.Forms.Label lblAverageAttendance8;
        private System.Windows.Forms.Label lblAverageAttendanceGirls;
        private System.Windows.Forms.Label lblAverageAttendanceBoys;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button btnAddSorts;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label lblAverageEffort7;
        private System.Windows.Forms.Label lblAverageEffortGirls;
        private System.Windows.Forms.Label lblAverageEffortBoys;
        private System.Windows.Forms.Label lblAverageEffort11;
        private System.Windows.Forms.Label lblAverageEffort10;
        private System.Windows.Forms.Label lblAverageEffort9;
        private System.Windows.Forms.Label lblAverageEffort8;
        private System.Windows.Forms.Label lblAverageAcademicGirls;
        private System.Windows.Forms.Label lblAverageAcademicBoys;
        private System.Windows.Forms.Label lblAverageAcademic11;
        private System.Windows.Forms.Label lblAverageAcademic10;
        private System.Windows.Forms.Label lblAverageAcademic9;
        private System.Windows.Forms.Label lblAverageAcademic8;
        private System.Windows.Forms.Label lblAverageAcademic7;
        private System.Windows.Forms.CheckBox chkYearEnable;
        private System.Windows.Forms.CheckBox chkHouseEnable;
        private System.Windows.Forms.CheckBox chkGenderEnable;
        private System.Windows.Forms.ComboBox cboFilter;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnClear;
    }
}