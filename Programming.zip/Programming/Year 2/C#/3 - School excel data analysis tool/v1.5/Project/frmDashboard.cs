﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Project
{
    public partial class frmDashboard : Form, IUserInterface
    {

        public frmDashboard()
        {
            InitializeComponent();
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {
            PopulateDropDowns();

            tabDashboard.BackColor = Color.Blue;
        }

        #region #####Home Tab#####

        public void HomeValues()
        {
            //boy/girls total
            double BoyAttendanceSum = 0;
            double GirlAttendanceSum = 0;
            double BoyEffortSum = 0;
            double GirlEffortSum = 0;
            double BoyAcademicSum = 0;
            double GirlAcademicSum = 0;

            for (int i = 0; i < GlobalData.CellH.Length; i++)
            {
                if (GlobalData.CellH[i] == "M")
                {
                    GlobalData.TotalBoys++;
                    BoyAttendanceSum = BoyAttendanceSum + GlobalData.CellA[i];
                    BoyEffortSum = BoyEffortSum + GlobalData.CellB[i];
                    BoyAcademicSum = BoyAcademicSum + GlobalData.CellC[i];
                }
                else if (GlobalData.CellH[i] == "F")
                {
                    GlobalData.TotalGirls++;
                    GirlAttendanceSum = GirlAttendanceSum + GlobalData.CellA[i];
                    GirlEffortSum = GirlEffortSum + GlobalData.CellB[i];
                    GirlAcademicSum = GirlAcademicSum + GlobalData.CellC[i];
                }
                else if (GlobalData.CellH[i] == "")
                {
                }
            }

            #region ###Attendance Averages###
            //Attendance Averages
            //Whole
            double AttendanceSum = GlobalData.CellA.Sum();
            GlobalData.AttendanceAverage = AttendanceSum / GlobalData.TotalRows;
            //Years
            for (int i = 0; i < GlobalData.CellZ.Length; i++)
            {
                if (GlobalData.CellZ[i].Equals(7))
                {

                    int Year7 = 0; Year7++;
                    double Year7Sum = 0; Year7Sum = Year7Sum + GlobalData.CellA[i];
                    GlobalData.AttendanceAverage7 = Year7Sum / Year7;
                }
                else if (GlobalData.CellZ[i].Equals(8))
                {
                    int Year8 = 0; Year8++;
                    double Year8Sum = 0; Year8Sum = Year8Sum + GlobalData.CellA[i];
                    GlobalData.AttendanceAverage8 = Year8Sum / Year8;
                }
                else if (GlobalData.CellZ[i].Equals(9))
                {
                    int Year9 = 0; Year9++;
                    double Year9Sum = 0; Year9Sum = Year9Sum + GlobalData.CellA[i];
                    GlobalData.AttendanceAverage9 = Year9Sum / Year9;
                }
                else if (GlobalData.CellZ[i].Equals(10))
                {
                    int Year10 = 0; Year10++;
                    double Year10Sum = 0; Year10Sum = Year10Sum + GlobalData.CellA[i];
                    GlobalData.AttendanceAverage10 = Year10Sum / Year10;
                }
                else if (GlobalData.CellZ[i].Equals(11))
                {
                    int Year11 = 0; Year11++;
                    double Year10Sum = 0; Year10Sum = Year10Sum + GlobalData.CellA[i];
                    GlobalData.AttendanceAverage11 = Year10Sum / Year11;
                }
            }
            //boy/girl
            GlobalData.AttendanceAverageBoys = BoyAttendanceSum / GlobalData.TotalBoys;
            GlobalData.AttendanceAverageGirls = GirlAttendanceSum / GlobalData.TotalGirls;
#endregion

            #region ###Effort Averages###

            //Effort Averages
            //Whole
            double EffortSum = GlobalData.CellB.Sum();
            GlobalData.EffortAverage = EffortSum / GlobalData.TotalRows;
            //years
            for (int i = 0; i < GlobalData.CellZ.Length; i++)
            {
                if (GlobalData.CellZ[i].Equals(7))
                {
                    int Year7 = 0; Year7++;
                    double Year7Sum = 0; Year7Sum = Year7Sum + GlobalData.CellB[i];
                    GlobalData.EffortAverage7 = Year7Sum / Year7;
                }
                else if (GlobalData.CellZ[i].Equals(8))
                {
                    int Year8 = 0; Year8++;
                    double Year8Sum = 0; Year8Sum = Year8Sum + GlobalData.CellB[i];
                    GlobalData.EffortAverage8 = Year8Sum / Year8;
                }
                else if (GlobalData.CellZ[i].Equals(9))
                {
                    int Year9 = 0; Year9++;
                    double Year9Sum = 0; Year9Sum = Year9Sum + GlobalData.CellB[i];
                    GlobalData.EffortAverage9 = Year9Sum / Year9;
                }
                else if (GlobalData.CellZ[i].Equals(10))
                {
                    int Year10 = 0; Year10++;
                    double Year10Sum = 0; Year10Sum = Year10Sum + GlobalData.CellB[i];
                    GlobalData.EffortAverage10 = Year10Sum / Year10;
                }
                else if (GlobalData.CellZ[i].Equals(11))
                {
                    int Year11 = 0; Year11++;
                    double Year11Sum = 0; Year11Sum = Year11Sum + GlobalData.CellB[i];
                    GlobalData.EffortAverage11 = Year11Sum / Year11;
                }
                //boy/girl
                GlobalData.EffortAverageBoys = BoyEffortSum / GlobalData.TotalBoys;
                GlobalData.EffortAverageGirls = GirlEffortSum / GlobalData.TotalGirls;
            }
            #endregion
            
            #region ###Academic Averages###

                //Academic Averages
                //Whole
                double AcademicSum = GlobalData.CellC.Sum();
                GlobalData.AcademicAverage = AcademicSum / GlobalData.TotalRows;
                //years
                for (int i = 0; i < GlobalData.CellZ.Length; i++)
                {
                    if (GlobalData.CellZ[i].Equals(7))
                    {
                        int Year7 = 0; Year7++;
                        double Year7Sum = 0; Year7Sum = Year7Sum + GlobalData.CellC[i];
                        GlobalData.AcademicAverage7 = Year7Sum / Year7;
                    }
                    else if (GlobalData.CellZ[i].Equals(8))
                    {
                        int Year8 = 0; Year8++;
                        double Year8Sum = 0; Year8Sum = Year8Sum + GlobalData.CellC[i];
                        GlobalData.AcademicAverage8 = Year8Sum / Year8;
                    }
                    else if (GlobalData.CellZ[i].Equals(9))
                    {
                        int Year9 = 0; Year9++;
                        double Year9Sum = 0; Year9Sum = Year9Sum + GlobalData.CellC[i];
                        GlobalData.AcademicAverage9 = Year9Sum / Year9;
                    }
                    else if (GlobalData.CellZ[i].Equals(10))
                    {
                        int Year10 = 0; Year10++;
                        double Year10Sum = 0; Year10Sum = Year10Sum + GlobalData.CellC[i];
                        GlobalData.AcademicAverage10 = Year10Sum / Year10;
                    }
                    else if (GlobalData.CellZ[i].Equals(11))
                    {
                        int Year11 = 0; Year11++;
                        double Year11Sum = 0; Year11Sum = Year11Sum + GlobalData.CellC[i];
                        GlobalData.AcademicAverage11 = Year11Sum / Year11;
                    }
                    //boy/girl
                    GlobalData.AcademicAverageBoys = BoyAcademicSum / GlobalData.TotalBoys;
                    GlobalData.AcademicAverageGirls = GirlAcademicSum / GlobalData.TotalGirls;

                #endregion

                    UpdateHomeInfo();
                
            }
        }

        public void UpdateHomeInfo()
        {
            //boys/girls
            lblSumStudents.Text = Convert.ToString(GlobalData.TotalBoys + GlobalData.TotalGirls);
            lblTotalBoys.Text = Convert.ToString(GlobalData.TotalBoys);
            lblTotalGirls.Text = Convert.ToString(GlobalData.TotalGirls);

            //Attendance
            lblAverageAttendance.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverage, 2));
            lblAverageAttendance7.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverage7, 2));
            lblAverageAttendance8.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverage8, 2));
            lblAverageAttendance9.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverage9, 2));
            lblAverageAttendance10.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverage10, 2));
            lblAverageAttendance11.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverage11, 2));
            lblAverageAttendanceBoys.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverageBoys, 2));
            lblAverageAttendanceGirls.Text = Convert.ToString(Math.Round(GlobalData.AttendanceAverageGirls, 2));
            
            //Effort
            lblAverageEffort.Text = Convert.ToString(Math.Round(GlobalData.EffortAverage, 2));
            lblAverageEffort7.Text = Convert.ToString(Math.Round(GlobalData.EffortAverage7, 2));
            lblAverageEffort8.Text = Convert.ToString(Math.Round(GlobalData.EffortAverage8, 2));
            lblAverageEffort9.Text = Convert.ToString(Math.Round(GlobalData.EffortAverage9, 2));
            lblAverageEffort10.Text = Convert.ToString(Math.Round(GlobalData.EffortAverage10, 2));
            lblAverageEffort11.Text = Convert.ToString(Math.Round(GlobalData.EffortAverage11, 2));
            lblAverageEffortBoys.Text = Convert.ToString(Math.Round(GlobalData.EffortAverageBoys, 2));
            lblAverageEffortGirls.Text = Convert.ToString(Math.Round(GlobalData.EffortAverageGirls, 2));

            //Academic
            lblAverageAcademic.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverage, 2));
            lblAverageAcademic7.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverage7, 2));
            lblAverageAcademic8.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverage8, 2));
            lblAverageAcademic9.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverage9, 2));
            lblAverageAcademic10.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverage10, 2));
            lblAverageAcademic11.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverage11, 2));
            lblAverageAcademicBoys.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverageBoys, 2));
            lblAverageAcademicGirls.Text = Convert.ToString(Math.Round(GlobalData.AcademicAverageGirls, 2));
        }

        #endregion

        #region #####Student Tab#####

        //gets array index from upn number 
        public void SearchStudent()
        {
            try
            {
                if (txtSearch.Text == "")
                {
                    lblWrongUpn.Text = "Please Enter UPN Number";
                }
                else
                {
                    
                    GlobalData.UPNNo = txtSearch.Text;

                    GlobalData.SearchedStudent = Array.FindIndex(GlobalData.CellJ, x => x.Contains(GlobalData.UPNNo));

                    lblWrongUpn.Text = "";
                    grpStudent.Visible = true;
                    UpdateSearchInfo();
                }
            }
            catch
            {
                lblWrongUpn.Text = "Incorrect UPN Number";
            }
        }

        //populates labels with searched student info
        public void UpdateSearchInfo()
        {
            lblForenameValue.Text = Convert.ToString(GlobalData.CellE[GlobalData.SearchedStudent]);
            lblSurnameValue.Text = Convert.ToString(GlobalData.CellD[GlobalData.SearchedStudent]);
            lblGenderValue.Text = Convert.ToString(GlobalData.CellH[GlobalData.SearchedStudent]);
            lblEthnicityValue.Text = Convert.ToString(GlobalData.CellQ[GlobalData.SearchedStudent]);
            lblLanguageValue.Text = Convert.ToString(GlobalData.CellS[GlobalData.SearchedStudent]);
            lblQuickNoteValue.Text = Convert.ToString(GlobalData.CellG[GlobalData.SearchedStudent]);
            lblLeaValue.Text = Convert.ToString(GlobalData.CellN[GlobalData.SearchedStudent]);
            lblSenValue.Text = Convert.ToString(GlobalData.CellT[GlobalData.SearchedStudent]);
            lblFreeMealValue.Text = Convert.ToString(GlobalData.CellU[GlobalData.SearchedStudent]);
            lblAdNumberValue.Text = Convert.ToString(GlobalData.CellI[GlobalData.SearchedStudent]);
            lblUpnNumberValue.Text = Convert.ToString(GlobalData.CellJ[GlobalData.SearchedStudent]);
            lblRegistrationValue.Text = Convert.ToString(GlobalData.CellK[GlobalData.SearchedStudent]);
            lblHouseValue.Text = Convert.ToString(GlobalData.CellL[GlobalData.SearchedStudent]);
            lblYearValue.Text = Convert.ToString(GlobalData.CellV[GlobalData.SearchedStudent]);
            lblPostCodeValue.Text = Convert.ToString(GlobalData.CellM[GlobalData.SearchedStudent]);
            lblAttendanceValue.Text = Convert.ToString(Math.Round(GlobalData.CellA[GlobalData.SearchedStudent], 2));
            lblEffortValue.Text = Convert.ToString(Math.Round(GlobalData.CellB[GlobalData.SearchedStudent], 2));
            lblAcademicValue.Text = Convert.ToString(Math.Round(GlobalData.CellC[GlobalData.SearchedStudent], 2));
        }

        #endregion

        #region #####Chart Tab#####

        public void PopulateDropDowns()
        {
            //Populate attendance drop down on charts
            cboAttendance.Items.Add("55");
            cboAttendance.Items.Add("60");
            cboAttendance.Items.Add("65");
            cboAttendance.Items.Add("70");
            cboAttendance.Items.Add("75");
            cboAttendance.Items.Add("80");
            cboAttendance.Items.Add("85");
            cboAttendance.Items.Add("90");
            cboAttendance.Items.Add("95");
            //Populate effort drop down on charts
            cboEffort.Items.Add("2");
            cboEffort.Items.Add("3");
            cboEffort.Items.Add("4");
            //Populate academic drop down on charts
            cboAcademic.Items.Add("2");
            cboAcademic.Items.Add("3");
            cboAcademic.Items.Add("4");
            //Populate sort options
            cboGender.Items.Add("M");
            cboGender.Items.Add("F");
            cboYear.Items.Add("7");
            cboYear.Items.Add("8");
            cboYear.Items.Add("9");
            cboYear.Items.Add("10");
            cboYear.Items.Add("11");
            cboHouse.Items.Add("Durham");
            cboHouse.Items.Add("Raby");
            cboHouse.Items.Add("Barnard");
            cboHouse.Items.Add("Lumley");
            //Populate filter options
            cboFilter.Items.Add("Gold");
            cboFilter.Items.Add("Silver");
            cboFilter.Items.Add("Bronze");
        }

        public void ChartData()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            #region ###Works out data###

            //Work out attendance bronze
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.GoldStudents++;
                }
            }
            #endregion

            //Copies data to sections
            lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
            lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
            lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
            lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
            lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
            lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
            lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

            lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);
        }

        public void PrintOutput()
        {
            if (cboGender.Text != "" && cboHouse.Text != "" && cboYear.Text != "")
            {
                for (int i = 0; i < GlobalData.CellA.Length; i++)
                {
                    if (GlobalData.CellH[i] == cboGender.Text && GlobalData.CellL[i] == cboHouse.Text && GlobalData.CellZ[i] == Convert.ToInt32(cboYear.Text))
                    {
                        string Firstname = GlobalData.CellE[i];
                        string Secondname = GlobalData.CellD[i];
                        string Year = GlobalData.CellV[i];
                        string House = GlobalData.CellL[i];
                        string UPN = GlobalData.CellJ[i];
                        string Complete = Firstname + ", " + Secondname + ", " + Year + ", " + House + ", " + UPN;
                        GlobalData.StudentOutput[i] = Complete;
                    }
                    else
                    {
                    }
                }

                File.WriteAllLines("Output.txt", GlobalData.StudentOutput);
            }
        }

        public void DisplayOutput()
        {
 
        }

        public void ChartDataYearSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            //populates venn with sorts
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.GoldStudents++;
                }

                //Copies data to sections
                lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
                lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
                lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
                lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
                lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

                lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);
            }
        }

        public void ChartDataYearGenderSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            //populates venn with sorts
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.GoldStudents++;
                }

                //Copies data to sections
                lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
                lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
                lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
                lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
                lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

                lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);

            }
        }

        public void ChartDataGenderSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            //populates venn with sorts
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.GoldStudents++;
                }

                //Copies data to sections
                lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
                lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
                lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
                lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
                lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

                lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);
            }
        }

        public void ChartDataHouseSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            //populates venn with sorts
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.GoldStudents++;
                }

                //Copies data to sections
                lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
                lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
                lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
                lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
                lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

                lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);
            }
        }

        public void ChartDataAllSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            #region ###Works out data###
            //Work out attendance bronze
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.Silver++;
                    GlobalData.AttendanceAcademicSilver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text))
                {
                    GlobalData.GoldStudents++;
                }
            }

            #endregion

            //Copies data to sections
            lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
            lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
            lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
            lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
            lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
            lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
            lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

            lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);

        }

        public void ChartDataYearHouseSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            //populates venn with sorts
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;

                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellZ[i] == Convert.ToDouble(cboYear.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.GoldStudents++;
                }

                //Copies data to sections
                lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
                lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
                lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
                lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
                lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

                lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);

            }
        }

        public void ChartDataGenderHouseSort()
        {
            #region ###Set chart values to 0###

            GlobalData.BronzeAttendance = 0;
            GlobalData.BronzeEffort = 0;
            GlobalData.BronzeAcademic = 0;
            GlobalData.AttendanceEffortSilver = 0;
            GlobalData.AttendanceAcademicSilver = 0;
            GlobalData.EffortAcademicSilver = 0;
            GlobalData.GoldStudents = 0;

            #endregion

            //populates venn with sorts
            for (int i = 0; i < GlobalData.CellA.Length; i++)
            {
                //Work out attendance bronze
                if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeAttendance++;
                    GlobalData.Bronze++;
                }
                //Work out effort bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeEffort++;
                    GlobalData.Bronze++;
                    
                }
                //Work out academic bronze
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.BronzeAcademic++;
                    GlobalData.Bronze++;
                }
                //works out attendance/effort silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] <= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceEffortSilver++;
                    GlobalData.Silver++;
                }
                //works out attendance/academic silver
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] <= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.AttendanceAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out effort/academic silver
                else if (GlobalData.CellA[i] <= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text))
                {
                    GlobalData.EffortAcademicSilver++;
                    GlobalData.Silver++;
                }
                //works out gold
                else if (GlobalData.CellA[i] >= Convert.ToDouble(cboAttendance.Text) && GlobalData.CellB[i] >= Convert.ToDouble(cboEffort.Text) && GlobalData.CellC[i] >= Convert.ToDouble(cboAcademic.Text) && GlobalData.CellH[i] == Convert.ToString(cboGender.Text) && GlobalData.CellL[i] == Convert.ToString(cboHouse.Text))
                {
                    GlobalData.GoldStudents++;
                    GlobalData.Gold++;
                }

                //Copies data to sections
                lblAttendance.Text = Convert.ToString(GlobalData.BronzeAttendance);
                lblAcademic.Text = Convert.ToString(GlobalData.BronzeAcademic);
                lblEffort.Text = Convert.ToString(GlobalData.BronzeEffort);
                lblAttendanceEffortSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblAttendanceAcademicSilver.Text = Convert.ToString(GlobalData.AttendanceAcademicSilver);
                lblEffortAcademicSilver.Text = Convert.ToString(GlobalData.EffortAcademicSilver);
                lblGold.Text = Convert.ToString(GlobalData.GoldStudents);

                lblTotalStudents.Text = Convert.ToString(GlobalData.BronzeAttendance + GlobalData.BronzeAcademic + GlobalData.BronzeEffort + GlobalData.EffortAcademicSilver + GlobalData.AttendanceEffortSilver + GlobalData.AttendanceAcademicSilver + GlobalData.GoldStudents);

            }
        }

        private void chkYearEnable_CheckedChanged(object sender, EventArgs e)
        {
            if (chkYearEnable.Checked == true)
            {
                cboYear.Enabled = true;
            }
            else
            {
                cboYear.Enabled = false;
            }
        }

        private void chkGenderEnable_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGenderEnable.Checked == true)
            {
                cboGender.Enabled = true;
            }
            else
            {
                cboGender.Enabled = false;
            }
        }

        private void chkHouseEnable_CheckedChanged(object sender, EventArgs e)
        {
            if (chkHouseEnable.Checked == true)
            {
                cboHouse.Enabled = true;
            }
            else
            {
                cboHouse.Enabled = false;
            }
        }

        public void FilterResults()
        {
            for (int i = 0; i <= GlobalData.Bronze; i++)
            {
                if (cboFilter.Text == "Bronze")
                {
                    listView1.Items.Add(GlobalData.CellE[i]);
                    //listView1.Items.Add(GlobalData.CellD[i]);
                    //listView1.Clear();
                }
            }

            for (int i = 0; i <= GlobalData.Silver; i++)
            {
                if (cboFilter.Text == "Silver")
                {
                    listView1.Items.Add(GlobalData.CellE[i]);
                    //listView1.Items.Add(GlobalData.CellD[j]);
                }
            }

            for (int i = 0; i <= GlobalData.Gold; i++)
            {
                if (cboFilter.Text == "Gold")
                {
                    listView1.Items.Add(GlobalData.CellE[i]);
                    //listView1.Items.Add(GlobalData.CellD[k]);
                }
            }
          
        }


        #endregion

        #region ##########Methods############

        //Retrieves excel file location and reads it into arrays
        public void ReadData()
        {
            openFileDialog1.Filter = "Excel files (*.xls,  *.xlsx) | *.xls; *.xlsx;";
            DialogResult result = openFileDialog1.ShowDialog();

            string filename = openFileDialog1.FileName;

            if (filename != "")
            {
                lblLoadStatus.Text = "Loading Data";
                tabDashboard.Enabled = true;

                Excel.Application appExl;
                Excel.Workbook workbook;
                Excel.Worksheet NwSheet;
                Excel.Range ShtRange;
                appExl = new Excel.Application();
                workbook = appExl.Workbooks.Open(filename);

                NwSheet = (Excel.Worksheet)workbook.Sheets.get_Item(1);
                ShtRange = NwSheet.UsedRange;

                #region ######Read columns######

                //Cell A
                List<double> rowAData = new List<double>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowAData.Add(Convert.ToDouble(NwSheet.get_Range("A" + r.ToString()).Value2));
                }
                GlobalData.TotalRows = ShtRange.Rows.Count;
                GlobalData.CellA = rowAData.ToArray();

                //Cell B
                List<double> rowBData = new List<double>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowBData.Add(Convert.ToDouble(NwSheet.get_Range("B" + r.ToString()).Value2));
                }
                GlobalData.CellB = rowBData.ToArray();

                //Cell C
                List<double> rowCData = new List<double>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowCData.Add(Convert.ToDouble(NwSheet.get_Range("C" + r.ToString()).Value2));
                }
                GlobalData.CellC = rowCData.ToArray();

                //Cell D
                List<string> rowDData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowDData.Add(Convert.ToString(NwSheet.get_Range("D" + r.ToString()).Value2));
                }
                GlobalData.CellD = rowDData.ToArray();

                //Cell E
                List<string> rowEData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowEData.Add(Convert.ToString(NwSheet.get_Range("E" + r.ToString()).Value2));
                }
                GlobalData.CellE = rowEData.ToArray();

                //Cell F
                List<string> rowFData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowFData.Add(Convert.ToString(NwSheet.get_Range("F" + r.ToString()).Value2));
                }
                GlobalData.CellF = rowFData.ToArray();

                //Cell G
                List<string> rowGData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowGData.Add(Convert.ToString(NwSheet.get_Range("G" + r.ToString()).Value2));
                }
                GlobalData.CellG = rowGData.ToArray();

                //Cell H
                List<string> rowHData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowHData.Add(Convert.ToString(NwSheet.get_Range("H" + r.ToString()).Value2));
                }
                GlobalData.CellH = rowHData.ToArray();

                //Cell I
                List<int> rowIData = new List<int>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowIData.Add(Convert.ToInt32(NwSheet.get_Range("I" + r.ToString()).Value2));
                }
                GlobalData.CellI = rowIData.ToArray();

                //Cell J
                List<string> rowJData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowJData.Add(Convert.ToString(NwSheet.get_Range("J" + r.ToString()).Value2));
                }
                GlobalData.CellJ = rowJData.ToArray();

                //Cell K
                List<string> rowKData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowKData.Add(Convert.ToString(NwSheet.get_Range("K" + r.ToString()).Value2));
                }
                GlobalData.CellK = rowKData.ToArray();

                //Cell L
                List<string> rowLData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowLData.Add(Convert.ToString(NwSheet.get_Range("L" + r.ToString()).Value2));
                }
                GlobalData.CellL = rowLData.ToArray();

                //Cell M
                List<string> rowMData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowMData.Add(Convert.ToString(NwSheet.get_Range("M" + r.ToString()).Value2));
                }
                GlobalData.CellM = rowMData.ToArray();

                //Cell N
                List<string> rowNData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowNData.Add(Convert.ToString(NwSheet.get_Range("N" + r.ToString()).Value2));
                }
                GlobalData.CellN = rowNData.ToArray();

                //Cell O
                List<double> rowOData = new List<double>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowOData.Add(Convert.ToDouble(NwSheet.get_Range("O" + r.ToString()).Value2));
                }
                GlobalData.CellO = rowOData.ToArray();

                //Cell P
                List<string> rowPData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowPData.Add(Convert.ToString(NwSheet.get_Range("P" + r.ToString()).Value2));
                }
                GlobalData.CellP = rowPData.ToArray();

                //Cell Q
                List<string> rowQData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowQData.Add(Convert.ToString(NwSheet.get_Range("Q" + r.ToString()).Value2));
                }
                GlobalData.CellQ = rowQData.ToArray();

                //Cell R
                List<string> rowRData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowRData.Add(Convert.ToString(NwSheet.get_Range("R" + r.ToString()).Value2));
                }
                GlobalData.CellR = rowRData.ToArray();

                //Cell S
                List<string> rowSData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowSData.Add(Convert.ToString(NwSheet.get_Range("S" + r.ToString()).Value2));
                }
                GlobalData.CellS = rowSData.ToArray();

                //Cell T
                List<string> rowTData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowTData.Add(Convert.ToString(NwSheet.get_Range("T" + r.ToString()).Value2));
                }
                GlobalData.CellT = rowTData.ToArray();

                //Cell U
                List<string> rowUData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowUData.Add(Convert.ToString(NwSheet.get_Range("U" + r.ToString()).Value2));
                }
                GlobalData.CellU = rowUData.ToArray();

                //Cell V
                List<string> rowVData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowVData.Add(Convert.ToString(NwSheet.get_Range("V" + r.ToString()).Value2));
                }
                GlobalData.CellV = rowVData.ToArray();

                //Cell W
                List<string> rowWData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowWData.Add(Convert.ToString(NwSheet.get_Range("W" + r.ToString()).Value2));
                }
                GlobalData.CellW = rowWData.ToArray();

                //Cell X
                List<int> rowXData = new List<int>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowFData.Add(Convert.ToString(NwSheet.get_Range("X" + r.ToString()).Value2));
                }
                GlobalData.CellX = rowXData.ToArray();

                //Cell Y
                List<string> rowYData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowYData.Add(Convert.ToString(NwSheet.get_Range("Y" + r.ToString()).Value2));
                }
                GlobalData.CellY = rowYData.ToArray();

                //Cell Z
                List<int> rowZData = new List<int>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowZData.Add(Convert.ToInt32(NwSheet.get_Range("Z" + r.ToString()).Value2));
                }
                GlobalData.CellZ = rowZData.ToArray();

                //Cell AA
                List<int> rowAAData = new List<int>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowAAData.Add(Convert.ToInt32(NwSheet.get_Range("AA" + r.ToString()).Value2));
                }
                GlobalData.CellAA = rowAAData.ToArray();

                //Cell AB
                List<string> rowABData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowABData.Add(Convert.ToString(NwSheet.get_Range("AB" + r.ToString()).Value2));
                }
                GlobalData.CellAB = rowABData.ToArray();

                //Cell AC
                List<string> rowACData = new List<string>();
                for (int r = 2; r < ShtRange.Rows.Count; r++)
                {
                    rowACData.Add(Convert.ToString(NwSheet.get_Range("AC" + r.ToString()).Value2));
                }
                GlobalData.CellAC = rowACData.ToArray();

                #endregion

                workbook.Close(true);
                appExl.Quit();

                btnImport.Visible = false;
                lblLoadStatus.Visible = false;
                HomeValues();
            }
            

        }

        #endregion

        #region #########Buttons##########

        //import button
        private void btnImport_Click(object sender, EventArgs e)
        {
            ReadData();
        }
        
        //home button
        private void lblHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tabDashboard.SelectedIndex = 0;
        }

        //students button
        private void lblStudents_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tabDashboard.SelectedIndex = 1;
        }
        
        //students tab search button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchStudent();
        }

        //Charts button
        private void lblCharts_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tabDashboard.SelectedIndex = 2;
        }

        private void btnAddSorts_Click(object sender, EventArgs e)
        {
            if (chkYearEnable.Checked == false && chkGenderEnable.Checked == false && chkHouseEnable.Checked == false)
            {
                ChartData();
            }
            else if (chkYearEnable.Checked == true && chkGenderEnable.Checked == true && chkHouseEnable.Checked == true)
            {
                ChartDataAllSort();
            }
            else if (chkYearEnable.Checked == true && chkGenderEnable.Checked == true)
            {
                ChartDataYearGenderSort();
            }
            else if (chkYearEnable.Checked == true && chkHouseEnable.Checked == true)
            {
                ChartDataYearHouseSort();
            }
            else if (chkGenderEnable.Checked == true && chkHouseEnable.Checked == true)
            {
                ChartDataGenderHouseSort();
            }
            else if (chkYearEnable.Checked == true)
            {
                ChartDataYearSort();
            }
            else if (chkGenderEnable.Checked == true)
            {
                ChartDataGenderSort();
            }
            else if (chkHouseEnable.Checked == true)
            {
                ChartDataHouseSort();
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintOutput();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            FilterResults();
        }
        #endregion

        private void btnClear_Click(object sender, EventArgs e)
        {
            listView1.Clear();
        }

        

        

        
    }
}

