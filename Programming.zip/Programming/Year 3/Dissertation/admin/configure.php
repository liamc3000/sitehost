<?php
  define('DB_HOSTNAME', '79.170.44.120');
  define('DB_USERNAME', 'web120-mystore');
  define('DB_SERVER_PASSWORD', 'database');
  define('DB_DATABASE', 'web120-mystore');
  define('ADDRESS_ID', 'www.liamcrosby.co.uk/store');
  define('STORE_ID', 'Test Store');
  define('OWNER_ID', 'Liam');
  define('EMAIL_ID', 'liam_crosby@hotmail.co.uk');
  define('ADMIN_ID', 'administrator');
  define('ADMIN_PASSWORD_ID', 'admin');
  define('Paypal_EMAIL', 'liam_crosby@hotmail.co.uk');
?>