<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />

</head>

<?php
//load config
if (file_exists('./configure.php')) {
    include('./configure.php');
	
	// Connect to server and select database.
	mysql_connect(DB_HOSTNAME, DB_USERNAME, DB_SERVER_PASSWORD)or die("cannot connect to database"); 
	mysql_select_db(DB_DATABASE)or die("cannot select DB");

	//filling tables
	$categoriesresult = mysql_query("select * from Categories");
	}
    else {
			header('Refresh: 1; URL= Installation.php');
	     }
?>

<body>
<div id="header-wrapper">
<div id="header" class="container">
	<div id="logo">
		<h1><strong><a href="index.php"><?php echo STORE_ID; ?></a></strong></a></h1>
	</div>
	
	<!-- TOP NAV BAR -->
	
	<div id="menu">
		<ul>
			<li class="current_page_item"><a href="index.php" accesskey="1" title="">Home</a></li>
			<li></br></br></br><form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
				<input type="hidden" name="cmd" value="_cart">
				<input type="hidden" name="business" value="<?php echo Paypal_EMAIL?>">
				<input type="image" align="center" src="https://www.paypal.com/en_US/i/btn/btn_viewcart_LG.gif" style="padding-left:10px; padding-top:2px;" border="0" name="submit" alt="">
				<img alt="" border="0" src="https://www.paypal.com/fr_FR/i/scr/pixel.gif" width="1" height="1">
				<input type="hidden" name="display" value="1">
				</form></li>
		</ul>
	</div>
</div>
</div>

	<!-- MAIN SECTION -->
		
<div id="page" class="container">
	
	<!-- LEFT COLUMN -->
	
	<div id="content">	
		<div class="leftcolumn">
		
		<!-- CATEGORIES -->
			<div class="title"><h2>Categories</h2></div>
			<hr>
			<!-- lists categories -->
			<table border=0 style="background-color:;" >
<?php				
while($row=mysql_fetch_array($categoriesresult)) 
{
	echo "<tr><td>";
	echo "<a href=\"ViewProduct.php?id="	. $row['id']	.	"\" style=\"text-decoration:none;\">" . $row['name'] . "</a>";
	echo "</td></tr>";
	
}
	echo "</table>";
?>
			</br>
			</br>
		<!-- SEARCH -->
			<div class="title"><h2>Search</h2></div>
			<hr>
			<form  method="post" action=""  id="searchform"> 
			<input  type="text" name="name" value="Not Working"> 
			<input  type="submit" name="submit" value="Search"> 
			</form> 
			</br>
			</br>
		<!-- About -->	
			<div class="title"><h2>About</h2></div>
			<hr>
			<a href="contact.php" style="text-decoration:none;">Contact Us</a>
			</br>
			</br>
		</div>

		<p></p>
	</div>
<?php
$productsresult = mysql_query("select * FROM Products");

if (!$productsresult)
{
	$rowcount=mysqli_num_rows($result);
}

?>	
	<!-- RIGHT COLUMN -->
	
	<div id="rightcolumn">
		<ul class="right1">
			<li class="first">
				<h3>New Items</h3>
				
				<p>
				
				<table border=0 style="background-color:;" > <!--creates table-->
				<tr>
				<th height="250" width="250">PUT ITEM 1</th>
				<th height="250" width="250">PUT ITEM 2</th>
				<th height="250" width="250">PUT ITEM 3</th> 
				</tr>
				<br>
				<tr>
				<th height="250" width="250">PUT ITEM 4</th>
				<th height="250" width="250">PUT ITEM 5</th>
				<th height="250" width="250">PUT ITEM 6</th> 
				</tr>
				</table>
				
				</br></br></p>
			</li>
		</ul>
	</div>
</div>

	<!-- FOOTER -->
<div id="footer">
	<?php
	echo "<p>| Copyright (c) "	.	STORE_ID .	" |</p>";
	?>
</div>
</body>
</html>
